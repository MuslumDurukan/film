$(function(){
	
	$("nav.kategoriler ul.kategori-baslik li").removeClass("aktif");
	$("nav.kategoriler ul.kategori-baslik li:first").addClass("aktif");
	$("nav.kategoriler ul.kategori-linkler-film, nav.kategoriler ul.kategori-linkler-dizi").hide();
	$("nav.kategoriler ul.kategori-linkler-film").show();
	
	
	
	$("nav.kategoriler ul.kategori-baslik li:first").click(function(){
		
		$("nav.kategoriler ul.kategori-baslik li").removeClass("aktif");
		$("nav.kategoriler ul.kategori-baslik li:first").addClass("aktif");
		
		$("nav.kategoriler ul.kategori-linkler-dizi").slideUp();
		$("nav.kategoriler ul.kategori-linkler-film").slideDown();
		
	});
	
	$("nav.kategoriler ul.kategori-baslik li:last").click(function(){
		
		$("nav.kategoriler ul.kategori-baslik li").removeClass("aktif");
		$("nav.kategoriler ul.kategori-baslik li:last").addClass("aktif");
		
		$("nav.kategoriler ul.kategori-linkler-film").slideUp();
		$("nav.kategoriler ul.kategori-linkler-dizi").slideDown();
		
	});
	
	$("nav.icerik-butonlar ul li.sag-buton-partlar").hover(function(){
		$("ul.partlar-sekmesi").stop().slideDown();
	},function(){
		$("ul.partlar-sekmesi").stop().slideUp();
	});
	
	$("nav.icerik-butonlar ul li.sag-buton-fragman").hover(function(){
		$("ul.vk-sekmesi").stop().slideDown();
	},function(){
		$("ul.vk-sekmesi").stop().slideUp();
	});
	
	// ---------------------------------------------------------- Responsive Menü
	$("#responsiveustMenuLinkler h2").click(function(){
		$("ul.responsiveustMenuLinkler").slideToggle();
	});
	
	$(".jquery-mavi-ekran").css("opacity","0.8");
	
	$("nav.blok-filmler ul.blok-film li").hover(function(){
		
		$(".jquery-mavi-ekran", this).stop().fadeIn();
		$(".jquery-film-blok", this).stop().fadeIn();
		
	},function(){
	
		$(".jquery-mavi-ekran", this).stop().fadeOut();
		$(".jquery-film-blok", this).stop().fadeOut();
	
	});
	
	
	
	// ---------------------------------------------------------- Resim Kaydırma		
	var sliderGenislik = $(".slider").width();
	var tumGenislik =$("nav.slider-resim ul.slider-resimler").width();
	$(".slider-kontroller-sol").hide();
	
	$(".slider-kontroller-sag").click(function(){
		
		if(tumGenislik-247 >=sliderGenislik){
			
			$(this).show();
			
			$("nav.slider-resim ul.slider-resimler").animate({
				marginLeft : "-=247"
			});
			
			tumGenislik-=247;
			
			$(".slider-kontroller-sol").slideDown();
		}else {
			$(this).slideUp();
			$(".slider-kontroller-sol").slideDown();
		}
		
	});
	
	$(".slider-kontroller-sol").click(function(){
	
		if(tumGenislik < 1976){
						
			$("nav.slider-resim ul.slider-resimler").animate({
				marginLeft : "+=247"
			});
			
			tumGenislik+=247;
			
			$(".slider-kontroller-sag").slideDown();
		
		}else {
			$(this).hide();
			$(".slider-kontroller-sag").slideDown();
		}
		
	});
	

	
	
	
	
	
	
	
	
	
	
	
	
});