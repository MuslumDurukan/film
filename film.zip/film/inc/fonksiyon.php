<?php 
function p($par){
    return addcslashes(trim($_POST[$par]), "\'\"\\");
}
function pa($par){
    return htmlspecialchars($_POST[$par], ENT_QUOTES, 'UTF-8');
}
function g($par){
    // Eğer $_GET[$par] tanımlı değilse, boş bir değer döndür
    return isset($_GET[$par]) ? strip_tags(trim(addcslashes($_GET[$par], "\'\"\\"))) : '';
}
function kisalt($par, $uzunluk = 23){
    // Bağlantıyı burada oluşturun
    $baglan = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatasını kontrol et
    if ($baglan->connect_error) {
        die("Bağlantı hatası: " . $baglan->connect_error);
    }
	
    if(mb_strlen($par, "UTF-8") > $uzunluk){
        $par = mb_substr($par, 0, $uzunluk, "UTF-8").'..';
    }
    return $par;
	
$baglan->close();
	
}
## title keyw desc ##
function title_keyw_desc(){
    // Bağlantıyı burada oluşturun
    $baglan = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatasını kontrol et
    if ($baglan->connect_error) {
        die("Bağlantı hatası: " . $baglan->connect_error);
    }

    $do = g("do");
    $seo = mysqli_query($baglan, "select * from seo");
    $seo_array = mysqli_fetch_array($seo);

    if($do == "izle"){
        $sef = g("sef");
        $query = mysqli_query($baglan, "select * from filmler where sef = '$sef'");
        $array = mysqli_fetch_array($query);

        $isim = $array['isim'];
        $title = $array['title'];

        $seo_title = $seo_array['title'];
        $seo_desc = $seo_array['description'];
        $seo_key = $seo_array['keywords'];

        $yeni_title = str_replace("{TITLE}", "$isim", $seo_title);
        $yeni_desc = str_replace("{TITLE}", "$isim", $seo_desc);
        $yeni_key = str_replace("{TITLE}", "$isim", $seo_key);

        if($title) {
            echo '<title>' . $title . '</title>';
        } else {
            echo '<title>' . $yeni_title . '</title>';
        }
        if($array['description']) {
            echo '<meta name="description" content="' . $array['description'] . '" />';
        } else {
            echo '<meta name="description" content="' . $yeni_desc . '" />';
        }
        if($array['keyw']) {
            echo '<meta name="keywords" content="' . $array['keyw'] . '"/>';
        } else {
            echo ' <meta name="keywords" content="' . $yeni_key . '" />';
        }
    }
elseif ($do == "kat") {
    $kat = g("kat");
    $query = mysqli_query($baglan, "select * from kategori where kat_seo = '$kat'");
    $array = mysqli_fetch_array($query);
    $isim = $array['kat_isim'];
    $title = $array['title'];
    $key = $array['keyw'];
    $desc = $array['description'];
    $yeni_title = str_replace("{TITLE}", "$isim", $seo_array['kat_title']);
    $yeni_desc = str_replace("{TITLE}", "$isim", $seo_array['kat_desc']);
    $yeni_key = str_replace("{TITLE}", "$isim", $seo_array['kat_key']);
    
    echo $title ? '<title>' . $title . '</title>' : '<title>' . $yeni_title . '</title>';
    echo $key ? '<meta name="keywords" content="' . $key . '" />' : '<meta name="keywords" content="' . $yeni_key . '" />';
    echo $desc ? '<meta name="description" content="' . $desc . '" />' : '<meta name="description" content="' . $yeni_desc . '" />';
}
elseif ($do == "hukuk") {
    echo '<title>' . $seo_array['hukuk_title'] . '</title>
        <meta name="description" content="' . $seo_array['hukuk_desc'] . '" />
        <meta name="keywords" content="' . $seo_array['hukuk_key'] . '" />';
}
elseif ($do == "turkcedublaj") {
    echo '<title>' . $seo_array['tr_title'] . '</title>
        <meta name="description" content="' . $seo_array['tr_desc'] . '" />
        <meta name="keywords" content="' . $seo_array['tr_key'] . '" />';
}
elseif ($do == "begenilenfilmler") {
    echo '<title>' . $seo_array['begen_title'] . '</title>
        <meta name="description" content="' . $seo_array['begen_desc'] . '" />
        <meta name="keywords" content="' . $seo_array['begen_key'] . '" />';
}
elseif ($do == "dizikat") {
    $sef = g("kat");
    $bul = mysqli_query($baglan, "select * from dizikat where kat_seo = '$sef'");
    $array = mysqli_fetch_array($bul);
    $isim = $array['kat_isim'];
    $title = $array['title'];
    $key = $array['keyw'];
    $desc = $array['description'];
    $yeni_title = str_replace("{TITLE}", "$isim", $seo_array['dizi_title']);
    $yeni_desc = str_replace("{TITLE}", "$isim", $seo_array['dizi_desc']);
    $yeni_key = str_replace("{TITLE}", "$isim", $seo_array['dizi_key']);
    echo $title ? '<title>' . $title . '</title>' : '<title>' . $yeni_title . '</title>';
    echo $key ? '<meta name="keywords" content="' . $key . '" />' : '<meta name="keywords" content="' . $yeni_key . '" />';
    echo $desc ? '<meta name="description" content="' . $desc . '" />' : '<meta name="description" content="' . $yeni_desc . '" />';
}
elseif ($do == "sezon") {
    $sef = g("sef");
    $bul = mysqli_query($baglan, "select * from dizisezon where sef = '$sef' ");
    $array = mysqli_fetch_array($bul);
    $isim = $array['sezonisim'];
    $title = $array['title'];
    $key = $array['keyw'];
    $desc = $array['description'];
    $yeni_title = str_replace("{TITLE}", "$isim", $seo_array['sezon_title']);
    $yeni_desc = str_replace("{TITLE}", "$isim", $seo_array['sezon_desc']);
    $yeni_key = str_replace("{TITLE}", "$isim", $seo_array['sezon_key']);
    echo $title ? '<title>' . $title . '</title>' : '<title>' . $yeni_title . '</title>';
    echo $key ? '<meta name="keywords" content="' . $key . '" />' : '<meta name="keywords" content="' . $yeni_key . '" />';
    echo $desc ? '<meta name="description" content="' . $desc . '" />' : '<meta name="description" content="' . $yeni_desc . '" />';
}
elseif ($do == "dizle") {
    $sef = g("sef");
    $query = mysqli_query($baglan, "select * from diziler where sef = '$sef' ");
    $array = mysqli_fetch_array($query);
    $isim = $array['isim'];
    $title = $array['title'];

    $seo_title = $seo_array['dizle_title'];
    $seo_desc = $seo_array['dizle_key'];
    $seo_key = $seo_array['dizle_desc'];

    $yeni_title = str_replace("{TITLE}", "$isim", $seo_title);
    $yeni_desc = str_replace("{TITLE}", "$isim", $seo_desc);
    $yeni_key = str_replace("{TITLE}", "$isim", $seo_key);

    echo $title ? '<title>' . $title . '</title>' : '<title>' . $yeni_title . '</title>';
    echo $array['description'] ? '<meta name="description" content="' . $array['description'] . '" />' : '<meta name="description" content="' . $yeni_desc . '" />';
    echo $array['keyw'] ? '<meta name="keywords" content="' . $array['keyw'] . '"/>' : '<meta name="keywords" content="' . $yeni_key . '" />';
}
else {
    $ana_title = $seo_array['ana_title'];
    $ana_key = $seo_array['ana_key'];
    $ana_desc = $seo_array['ana_desc'];

    echo '<title>' . $ana_title . '</title>
    <meta name="description" content="' . $ana_desc . '" />
    <meta name="keywords" content="' . $ana_key . '" />';
}
$baglan->close();
  }
?>