<?php
ob_start();
session_start();

## LİSANS##
$key = "123123124124";
## Bağlantı değişkenleri ##

$host = "localhost";
$user = "root";
$pass = "";
$db   = "film";

## Mysql bağlantısı ##

$baglan = mysqli_connect($host, $user, $pass, $db);

## Veritabanı Seçimi ##
$vt_baglan = mysqli_select_db($baglan, $db) or die(mysqli_error($baglan));

## Karakter Sorunu ##
mysqli_query($baglan, "SET CHARACTER SET 'utf8'");
mysqli_query($baglan, "SET NAMES 'utf8'");

## Genel ayalar ##
$site_ayar = mysqli_query($baglan, "SELECT * FROM seo");
$site_ayar_array = mysqli_fetch_array($site_ayar);

## Sabitler ##
define("URL", $site_ayar_array["site_url"]);
define("FILMSAYISI", 12);
define("FILMURL", "filmizle");
define("KATEGORURL", "kategori");
define("SAYFAURL", "sayfa");
define("DIZIKATURL", "dizi");
define("SEZONURL", "sezon");
define("DIZIIZLEURL", "dizle");
require_once("sistem.php");

#Admin Paneli#
define("adminuser", "m8c");
define("adminpass", "mustafa97");
?>