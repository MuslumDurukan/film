<?php 

require_once("fonksiyon.php");

## Sistem İçerik DO ##

function site_icerik(){
    $do = g("do");

    switch ($do){
        case "izle":
            require_once "sayfa/izle.php";
            break;

        case "kat":
            require_once "sayfa/kategori.php";
            break;

        case "ara":
            require_once "sayfa/ara.php";
            break;

        case "etiket":
            require_once "sayfa/etiket.php";
            break;

        case "hukuk":
            require_once "sayfa/hukuksal.php";
            break;

        case "begenilenfilmler":
            require_once "sayfa/begenilenfilmler.php";
            break;

        case "tag":
            require_once "sayfa/tag.php";
            break;

        case "dizikat":
            require_once "sayfa/dizikategori.php";
            break;

        case "turkcedublaj":
            require_once "sayfa/turkcedublaj.php";
            break;

        case "sezon":
            require_once "sayfa/sezon.php";
            break;

        case "dizle":
            require_once "sayfa/dizle.php";
            break;

        case "404":
            require_once "sayfa/404.php";
            break;

        default:
            require_once "sayfa/default.php";
            break;
    }
}

   



   ## Kategori Listeme ##

function kategori_listele() {
    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $query = $conn->query("SELECT * FROM kategori");

    if ($query->num_rows > 0) {
        while ($row = $query->fetch_assoc()) {
            echo '<li><a href="' . URL . '/' . KATEGORURL . '/' . $row['kat_seo'] . '">' . $row['kat_isim'] . '</a></li>';
        }
    }

    $conn->close();
}

   ## Kategori Listeme ##

function dizi_kat_listele() {
    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $query = $conn->query("SELECT * FROM dizikat");

    if ($query->num_rows > 0) {
        while ($row = $query->fetch_assoc()) {
            echo '<li><a href="' . URL . '/' . DIZIKATURL . '/' . $row['kat_seo'] . '">' . $row['kat_isim'] . '</a></li>';
        }
    }

    $conn->close();
}

 

   ## Tema Manşet ##

function tema_manset() {
    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $query = $conn->query("SELECT * FROM filmler WHERE manset = 1 ORDER BY id DESC");

    if ($query->num_rows > 0) {
        while ($array = $query->fetch_assoc()) {
            $baslik = $array['isim'];
            $resim = $array['resim'];
            $sef = $array['sef'];
            echo '<li><a href="' . URL . '/' . FILMURL . '/' . $sef . '"><img width="220" height="280" src="' . $resim . '" width="116" height="151" alt="' . $baslik . '"/></a></li>';
        }
    }

    $conn->close();
}



 

   ## Tema Default En son eklenenler ##

function enson_eklenen() {
    $filmsayisi = FILMSAYISI;
    $sayfa = @intval(g("sayfa"));

    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    if ($sayfa) {
        $sayfa = $sayfa - 1;
        $gosterim = $filmsayisi * $sayfa;
        $query = $conn->query("SELECT * FROM filmler ORDER BY id DESC LIMIT $gosterim, $filmsayisi");
    } else {
        $query = $conn->query("SELECT * FROM filmler ORDER BY id DESC LIMIT 0, $filmsayisi");
    }

    while ($array = $query->fetch_assoc()) {
        $baslik = $array['isim'];
        $resim = $array['resim'];
        $dublaj = $array['dublaj'];
        $imdb = $array['imdb'];
        $sef = $array['sef'];

        if (mb_strlen($baslik, "UTF-8") > 18) {
            $baslik = mb_substr($baslik, 0, 18, "UTF-8") . '...';
        }

        echo '<li><img width="220" height="280" alt="' . $baslik . '" src="' . $resim . '" />
            <div class="jquery-mavi-ekran"></div>
            <div class="jquery-film-blok">';

        if ($dublaj == 0) {
            echo '<a href="/' . FILMURL . '/' . $sef . '" class="tr">Yerli Film</a>';
        } elseif ($dublaj == 1) {
            echo '<a href="/' . FILMURL . '/' . $sef . '" class="tr">Tr Dublaj</a>';
        } elseif ($dublaj == 2) {
            echo '<a href="/' . FILMURL . '/' . $sef . '" class="tr">Alt Yazı</a>';
        }

        echo '<a href="' . URL . '/' . FILMURL . '/' . $sef . '" class="hd">HD</a>
            <a href="' . URL . '/' . FILMURL . '/' . $sef . '"><img src="' . URL . '/images/jquery-film-ok.png" alt="Jquery film ok" class="jquery-film-ok" /></a>
            <p class="jquery-film-yazi">' . $baslik . ' <br /> <span>İmdb : ' . $imdb . ' </span></p>
        </div></li>';
    }

    $conn->close();
}

 

 

   ## Kategori Film Sırala ##

function kategori_video() {
    $filmsayisi = FILMSAYISI;
    $kat = g("kat");

    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $query = $conn->query("SELECT * FROM kategori WHERE kat_seo = '$kat'");
    $say = $query->num_rows;

    if ($say > 0) {
        $kat_array = $query->fetch_assoc();
        $kat_id = ',' . $kat_array['id'] . ',';

        $sayfa = @intval(g("sayfa"));

        if ($sayfa) {
            $sayfa = $sayfa - 1;
            $gosterim = $filmsayisi * $sayfa;
            $video_bul = $conn->query("SELECT * FROM filmler WHERE kategori LIKE '%$kat_id%' ORDER BY id DESC LIMIT $gosterim, $filmsayisi");
        } else {
            $video_bul = $conn->query("SELECT * FROM filmler WHERE kategori LIKE '%$kat_id%' ORDER BY id DESC LIMIT 0, $filmsayisi");
        }

        while ($video_query = $video_bul->fetch_assoc()) {
            $baslik = $video_query['isim'];
            $resim = $video_query['resim'];
            $dublaj = $video_query['dublaj'];
            $imdb = $video_query['imdb'];
            $sef = $video_query['sef'];

            if (mb_strlen($baslik, "UTF-8") > 18) {
                $baslik = mb_substr($baslik, 0, 18, "UTF-8") . '..';
            }

            echo '<li><img width="220" height="280" alt="' . $baslik . '" src="' . $resim . '" />
                    <div class="jquery-mavi-ekran"></div>
                    <div class="jquery-film-blok">';

            if ($dublaj == 0) {
                echo '<a href="' . URL . '/' . FILMURL . '/' . $sef . '" class="tr">Yerli Film</a>';
            } elseif ($dublaj == 1) {
                echo '<a href="' . URL . '/' . FILMURL . '/' . $sef . '" class="tr">Tr Dublaj</a>';
            } elseif ($dublaj == 2) {
                echo '<a href="' . URL . '/' . FILMURL . '/' . $sef . '" class="tr">Alt Yazı</a>';
            }

            echo '<a href="' . URL . '/' . FILMURL . '/' . $sef . '" class="hd">HD</a>
                    <a href="' . URL . '/' . FILMURL . '/' . $sef . '"><img src="' . URL . '/images/jquery-film-ok.png" alt="Jquery film ok" class="jquery-film-ok" /></a>
                    <p class="jquery-film-yazi">' . $baslik . ' <br /> <span>İmdb : ' . $imdb . ' </span></p>
                </div></li>';
        }
    } else {
        header("Location:" . URL . "/404");
        echo '<meta http-equiv="refresh" content="0;URL=' . URL . '/404">';
    }

    $conn->close();
}

 

   ## Kategori Sayfala ##

function kategori_sayfa_ileri_geri() {
    $kat = @g("kat");
    $filmsayisi = FILMSAYISI;

    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $kat_query = $conn->query("SELECT * FROM kategori WHERE kat_seo = '$kat'");
    $kat_array = $kat_query->fetch_assoc();
    $kat_id = ',' . $kat_array['id'] . ',';

    $sayfa = @intval(g("sayfa"));

    if (!$sayfa) {
        $sayfa = 1;
    }

    $geri = $sayfa - 1;
    $ileri = $sayfa + 1;

    if (!$sayfa || $sayfa == 0 || $sayfa == 1) {
        echo '<a href="#"><li class="sayfalama-geri">Geri</li></a>';
    } else {
        echo '<a href="' . URL . '/' . KATEGORURL . '/' . $kat . '/' . $geri . '"><li class="sayfalama-geri">Geri</li></a>';
    }

    $query = $conn->query("SELECT * FROM filmler WHERE kategori LIKE '%$kat_id%' ");
    $say = $query->num_rows;
    $bol = ceil($say / $filmsayisi);

    if ($bol == $sayfa) {
        echo '<a href="#"><li class="sayfalama-ileri">İleri</li></a>';
    } elseif ($bol < $sayfa) {
        echo '<a href="#"><li class="sayfalama-ileri">İleri</li></a>';
    } elseif (!$sayfa || $sayfa == 0 || $sayfa == 1) {
        echo '<a href="' . URL . '/' . KATEGORURL . '/' . $kat . '/2"><li class="sayfalama-ileri">İleri</li></a>';
    } else {
        echo '<a href="' . URL . '/' . KATEGORURL . '/' . $kat . '/' . $ileri . '"><li class="sayfalama-ileri">İleri</li></a>';
    }

    if ($sayfa > $bol) {
        if ($bol == 0) {
        } else {
            header("Location:" . URL . "/404");
            echo '<meta http-equiv="refresh" content="0;URL=' . URL . '/404">';
        }
    }

    $conn->close();
}



function kategori_sayfa() {
    $kat = @g("kat");
    $filmsayisi = FILMSAYISI;

    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $kat_query = $conn->query("SELECT * FROM kategori WHERE kat_seo = '$kat'");
    $kat_array = $kat_query->fetch_assoc();
    $kat_id = ',' . $kat_array['id'] . ',';

    $sayfa = @intval(g("sayfa"));

    if (!$sayfa) {
        $sayfa = 1;
    }

    $query = $conn->query("SELECT * FROM filmler WHERE kategori LIKE '%$kat_id%' ");
    $say = $query->num_rows;
    $bol = ceil($say / $filmsayisi);
    $for_limit = 10;

    for ($i = $sayfa - $for_limit; $i < $sayfa + $for_limit; $i++) {
        if ($i > 0 && $i <= $bol) {
            if ($i == $sayfa) {
                echo '<li><a class="active"  href="' . URL . '/' . KATEGORURL . '/' . $kat . '/' . $i . '">' . $i . '</a></li>';
            } else {
                echo '<li><a href="' . URL . '/' . KATEGORURL . '/' . $kat . '/' . $i . '">' . $i . '</a></li>';
            }
        }
    }

    $conn->close();
}

   

   ## Ana Sayfa sayfalama ##

function anasayfa_ileri_geri() {
    $filmsayisi = FILMSAYISI;

    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $sayfa = @intval(g("sayfa"));

    if (!$sayfa) {
        $sayfa = 1;
    }

    $geri = $sayfa - 1;
    $ileri = $sayfa + 1;

    if (!$sayfa || $sayfa == 0 || $sayfa == 1) {
        echo '<a href="#"><li class="sayfalama-geri">Geri</li></a>';
    } else {
        echo '<a href="' . URL . '/sayfa/' . $geri . '"><li class="sayfalama-geri">Geri</li></a>';
    }

    $query = $conn->query("SELECT * FROM filmler");
    $say = $query->num_rows;
    $bol = ceil($say / $filmsayisi);

    if ($bol == $sayfa) {
        echo '<a href="#"><li class="sayfalama-ileri">İleri</li></a>';
    } elseif ($bol < $sayfa) {
        echo '<a href="#"><li class="sayfalama-ileri">İleri</li></a>';
    } elseif (!$sayfa || $sayfa == 0 || $sayfa == 1) {
        echo '<a href="' . URL . '/sayfa/2"><li class="sayfalama-ileri">İleri</li></a>';
    } else {
        echo '<a href="' . URL . '/sayfa/' . $ileri . '"><li class="sayfalama-ileri">İleri</li></a>';
    }

    if ($sayfa > $bol) {
        if ($bol == 0) {
        } else {
            header("Location:" . URL . "/404");
            echo '<meta http-equiv="refresh" content="0;URL=' . URL . '/404">';
        }
    }

    $conn->close();
}

   

function ana_sayfa_sayfalma() {
    $filmsayisi = FILMSAYISI;

    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $sayfa = @intval(g("sayfa"));

    if (!$sayfa) {
        $sayfa = 1;
    }

    $query = $conn->query("SELECT * FROM filmler");
    $say = $query->num_rows;
    $bol = ceil($say / $filmsayisi);

    $for_limit = 10;

    for ($i = $sayfa - $for_limit; $i < $sayfa + $for_limit; $i++) {
        if ($i > 0 && $i <= $bol) {
            if ($i == $sayfa) {
                echo '<li><a class="active"  href="' . URL . '/sayfa/' . $i . '">' . $i . '</a></li>';
            } else {
                echo '<li><a href="' . URL . '/sayfa/' . $i . '">' . $i . '</a></li>';
            }
        }
    }

    $conn->close();
}
  

   ## Tema Çok Beğenilenler ##

function en_cok_begeni_film() {
    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $query = $conn->query("SELECT * FROM filmler ORDER BY begeni DESC LIMIT 18");

    while ($array = $query->fetch_assoc()) {
        $baslik = $array['isim'];
        $resim = $array['resim'];
        $dublaj = $array['dublaj'];
        $imdb = $array['imdb'];
        $sef = $array['sef'];

        if (mb_strlen($baslik, "UTF-8") > 18) {
            $baslik = mb_substr($baslik, 0, 18, "UTF-8") . '...';
        }

        echo '
            <li>
                <img width="220" height="280" alt="' . $baslik . '" src="' . $resim . '" />
                <div class="jquery-mavi-ekran"></div>
                <div class="jquery-film-blok">';

        if ($dublaj == 0) {
            echo '<a href="/' . FILMURL . '/' . $sef . '" class="tr">Yerli Film</a>';
        } elseif ($dublaj == 1) {
            echo '<a href="/' . FILMURL . '/' . $sef . '" class="tr">Tr Dublaj</a>';
        } elseif ($dublaj == 2) {
            echo '<a href="/' . FILMURL . '/' . $sef . '" class="tr">Alt Yazı</a>';
        }

        echo '
            <a href="' . URL . '/' . FILMURL . '/' . $sef . '" class="hd">HD</a>
            <a href="' . URL . '/' . FILMURL . '/' . $sef . '"><img src="' . URL . '/images/jquery-film-ok.png" alt="Jquery film ok" class="jquery-film-ok" /></a>
            <p class="jquery-film-yazi">' . $baslik . ' <br /> <span>İmdb : ' . $imdb . ' </span></p>
            </div>
            </li>';
    }

    $conn->close();
}



   ## Türkçe Dublaj Filmler ##

function turkce_dublaj_film() {
    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $filmsayisi = FILMSAYISI;
    $sayfa = @intval(g("sayfa"));

    if ($sayfa) {
        $sayfa = $sayfa - 1;
        $gosterim = $filmsayisi * $sayfa;
        $query = $conn->query("SELECT * FROM filmler WHERE dublaj = 1 ORDER BY id DESC LIMIT $gosterim, $filmsayisi");
    } else {
        $query = $conn->query("SELECT * FROM filmler WHERE dublaj = 1 ORDER BY id DESC LIMIT 0, $filmsayisi");
    }

    while ($array = $query->fetch_assoc()) {
        $baslik = $array['isim'];
        $resim = $array['resim'];
        $dublaj = $array['dublaj'];
        $imdb = $array['imdb'];
        $sef = $array['sef'];

        if (mb_strlen($baslik, "UTF-8") > 18) {
            $baslik = mb_substr($baslik, 0, 18, "UTF-8") . '...';
        }

        echo '
            <li>
                <img width="220" height="280" alt="' . $baslik . '" src="' . $resim . '" />
                <div class="jquery-mavi-ekran"></div>
                <div class="jquery-film-blok">';

        if ($dublaj == 0) {
            echo '<a href="' . URL . '/' . FILMURL . '/' . $sef . '" class="tr">Yerli Film</a>';
        } elseif ($dublaj == 1) {
            echo '<a href="' . URL . '/' . FILMURL . '/' . $sef . '" class="tr">Tr Dublaj</a>';
        } elseif ($dublaj == 2) {
            echo '<a href="' . URL . '/' . FILMURL . '/' . $sef . '" class="tr">Alt Yazı</a>';
        }

        echo '
            <a href="' . URL . '/' . FILMURL . '/' . $sef . '" class="hd">HD</a>
            <a href="' . URL . '/' . FILMURL . '/' . $sef . '"><img src="' . URL . '/images/jquery-film-ok.png" alt="Jquery film ok" class="jquery-film-ok" /></a>
            <p class="jquery-film-yazi">' . $baslik . ' <br /> <span>İmdb : ' . $imdb . ' </span></p>
            </div>
            </li>';
    }

    $conn->close();
}  

     

function turkce_dublaj_ileri_geri() {
    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $filmsayisi = FILMSAYISI;
    $sayfa = @intval(g("sayfa"));

    if (!$sayfa) {
        $sayfa = 1;
    }

    $geri = $sayfa - 1;
    $ileri = $sayfa + 1;

    if (!$sayfa || $sayfa == 0 || $sayfa == 1) {
        echo '<a href="#"><li class="sayfalama-geri">Geri</li></a>';
    } else {
        echo '<a href="' . URL . '/turkce-dublaj/' . $geri . '"><li class="sayfalama-geri">Geri</li></a>';
    }

    $query = $conn->query("SELECT * FROM filmler WHERE dublaj = 1");
    $say = $query->num_rows;
    $bol = ceil($say / $filmsayisi);

    if ($bol == $sayfa) {
        echo '<a href="#"><li class="sayfalama-ileri">İleri</li></a>';
    } elseif ($bol < $sayfa) {
        echo '<a href="#"><li class="sayfalama-ileri">İleri</li></a>';
    } elseif (!$sayfa || $sayfa == 0 || $sayfa == 1) {
        echo '<a href="' . URL . '/turkce-dublaj/2"><li class="sayfalama-ileri">İleri</li></a>';
    } else {
        echo '<a href="' . URL . '/turkce-dublaj/' . $ileri . '"><li class="sayfalama-ileri">İleri</li></a>';
    }

    if ($sayfa > $bol) {
        if ($bol == 0) {
        } else {
            header("Location:" . URL . "/404");
            echo '<meta http-equiv="refresh" content="0;URL=' . URL . '/404">';
        }
    }

    $conn->close();
}

     

function turce_dublaj_sayfalama() {
    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $filmsayisi = FILMSAYISI;
    $sayfa = @intval(g("sayfa"));

    if (!$sayfa) {
        $sayfa = 1;
    }

    $query = $conn->query("SELECT * FROM filmler WHERE dublaj = 1");
    $say = $query->num_rows;
    $bol = ceil($say / $filmsayisi);

    $for_limit = 10;

    for ($i = $sayfa - $for_limit; $i < $sayfa + $for_limit; $i++) {
        if ($i > 0 && $i <= $bol) {
            if ($i == $sayfa) {
                echo '<li><a class="active"  href="' . URL . '/turkce-dublaj/' . $i . '">' . $i . '</a></li>';
            } else {
                echo '<li><a href="' . URL . '/turkce-dublaj/' . $i . '">' . $i . '</a></li>';
            }
        }
    }

    $conn->close();
}

  

  

   ## Arama ##

function arama_video() {
    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $filmsayisi = FILMSAYISI;
    $kelime = $conn->real_escape_string(g("kelime"));
    $sayfa = @intval(g("sayfa"));

    $query = $conn->query("SELECT * FROM filmler WHERE isim LIKE '%$kelime%' ORDER BY id");
    $say = $query->num_rows;

    if ($say > 0) {
        while ($array = $query->fetch_assoc()) {
            $baslik = $array['isim'];
            $resim  = $array['resim'];
            $dublaj = $array['dublaj'];
            $imdb   = $array['imdb'];
            $sef   = $array['sef'];

            if (mb_strlen($baslik, "UTF-8") > 18) {
                $baslik = mb_substr($baslik, 0, 18, "UTF-8") . '...';
            }

            echo '
            <li>
                <img width="220" height="280" alt="'.$baslik.'" src="'.$resim.'" />
                <div class="jquery-mavi-ekran"></div>
                <div class="jquery-film-blok">';

            if ($dublaj == 0) {
                echo '<a href="/'.FILMURL.'/'.$sef.'" class="tr">Yerli Film</a>';
            } elseif ($dublaj == 1) {
                echo '<a href="/'.FILMURL.'/'.$sef.'" class="tr">Tr Dublaj</a>';
            } elseif ($dublaj == 2) {
                echo '<a href="/'.FILMURL.'/'.$sef.'" class="tr">Alt Yazı</a>';
            }

            echo '
                <a href="'.URL.'/'.FILMURL.'/'.$sef.'" class="hd">HD</a>
                <a href="'.URL.'/'.FILMURL.'/'.$sef.'">
                    <img src="'.URL.'/images/jquery-film-ok.png" alt="Jquery film ok" class="jquery-film-ok" />
                </a>
                <p class="jquery-film-yazi">
                    '.$baslik.' <br /> <span>İmdb : '.$imdb.' </span>
                </p>
            </div>
            </li>';
        }
    } else {
        echo '<font class="yazi" >ARADIĞINIZ Film bulunamadı</font>';
    }

    $conn->close();
}

   
function arama_ileri_geri() {
    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $filmsayisi = FILMSAYISI;
    $kelime = $conn->real_escape_string(g("kelime"));
    $sayfa = @intval(g("sayfa"));

    $geri = $sayfa - 1;
    $ileri = $sayfa + 1;

    if (!$sayfa || $sayfa == 0 || $sayfa == 1) {
        echo '<a href="#"><li class="sayfalama-geri">Geri</li></a>';
    } else {
        echo '<a href="'.URL.'/index.php?kelime='.$kelime.'&do=ara/'.$geri.'"><li class="sayfalama-geri">Geri</li></a>';
    }

    $query = $conn->query("SELECT * FROM filmler WHERE isim LIKE '%$kelime%'");
    $say = $query->num_rows;

    $bol = ceil($say / $filmsayisi);

    if ($bol == $sayfa) {
        echo '<a href="#"><li class="sayfalama-ileri">İleri</li></a>';
    } elseif ($bol < $sayfa) {
        echo '<a href="#"><li class="sayfalama-ileri">İleri</li></a>';
    } elseif (!$sayfa || $sayfa == 0 || $sayfa == 1) {
        echo '<a href="'.URL.'/index.php?kelime='.$kelime.'&do=ara/2"><li class="sayfalama-ileri">İleri</li></a>';
    } else {
        echo '<a href="'.URL.'/index.php?kelime='.$kelime.'&do=ara/'.$ileri.'"><li class="sayfalama-ileri">İleri</li></a>';
    }

    if ($sayfa > $bol) {
        if ($bol == 0) {
        } else {
            header("Location:".URL."/404");
            echo '<meta http-equiv="refresh" content="0;URL='.URL.'/404">';
        }
    }

    $conn->close();
}

   

function arama_sayfalama() {
    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $filmsayisi = FILMSAYISI;
    $kelime = $conn->real_escape_string(g("kelime"));
    $sayfa = @intval(g("sayfa"));

    if (!$sayfa) {
        $sayfa = 1;
    }

    $query = $conn->query("SELECT * FROM filmler WHERE isim LIKE '%$kelime%'");
    $say = $query->num_rows;

    $bol = ceil($say / $filmsayisi);
    $for_limit = 10;

    for ($i = $sayfa - $for_limit; $i < $sayfa + $for_limit; $i++) {
        if ($i > 0 && $i <= $bol) {
            if ($i == $sayfa) {
                echo '<li><a class="active" href="'.URL.'/index.php?kelime='.$kelime.'&do=ara/'.$i.'">'.$i.'</a></li>';
            } else {
                echo '<li><a href="'.URL.'/index.php?kelime='.$kelime.'&do=ara/'.$i.'">'.$i.'</a></li>';
            }
        }
    }

    $conn->close();
}

   

function sezon_sırala() {
    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $kat = $conn->real_escape_string(g("kat"));
    $ara = $conn->query("SELECT * FROM dizikat WHERE kat_seo = '$kat'");
    $array = $ara->fetch_array(MYSQLI_ASSOC);

    $id = $array['id'];

    $sezon_ara = $conn->query("SELECT * FROM dizisezon WHERE dizikatid = '$id'");

    while ($array_sezon = $sezon_ara->fetch_array(MYSQLI_ASSOC)) {
        echo '<li>
                <div>
                    <div><a href="'.URL.'/'.SEZONURL.'/'.$array_sezon['sef'].'"><img height="168" width="300" src="'.$array_sezon['resim_url'].'" /></a></div>
                    <a href="" style="color:black;"><div width="" height=""><font class="sezon">'.$array_sezon['sezonisim'].'</font></a>
                </div>
            </li>';
    }

    $conn->close();
}

   

   #sezon#

   

function sezon_video() {
    $filmsayisi = FILMSAYISI;
    $sef = g('sef');

    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $query = $conn->query("SELECT * FROM dizisezon WHERE sef = '$sef'");
    $array = $query->fetch_assoc();
    $id = $array['id'];

    $say = $query->num_rows;

    if ($say > 0) {
        $sayfa = @intval(g("sayfa"));

        if ($sayfa) {
            $sayfa = $sayfa - 1;
            $gosterim = $filmsayisi * $sayfa;
            $video_bul = $conn->query("SELECT * FROM diziler WHERE kategori = '$id' ORDER BY id DESC LIMIT $gosterim, $filmsayisi");
        } else {
            $video_bul = $conn->query("SELECT * FROM diziler WHERE kategori = '$id' ORDER BY id DESC LIMIT 0, $filmsayisi");
        }

        while ($video_query = $video_bul->fetch_assoc()) {
            $baslik = $video_query['isim'];
            $resim = $video_query['resim'];
            $dublaj = $video_query['dublaj'];
            $sef = $video_query['sef'];

            if (strlen($baslik) > 18) {
                $baslik = mb_substr($baslik, 0, 18, "UTF-8") . '..';
            }

            echo '<li><img width="220" height="280" alt="' . $baslik . '" src="' . $resim . '" />
                    <div class="jquery-mavi-ekran"></div>
                    <div class="jquery-film-blok">';

            if ($dublaj == 0) {
                echo '<a href="' . URL . '/' . DIZIIZLEURL . '/' . $sef . '" class="tr">Yerli Film</a>';
            } elseif ($dublaj == 1) {
                echo '<a href="' . URL . '/' . DIZIIZLEURL . '/' . $sef . '" class="tr">Tr Dublaj</a>';
            } elseif ($dublaj == 2) {
                echo '<a href="' . URL . '/' . DIZIIZLEURL . '/' . $sef . '" class="tr">Alt Yazı</a>';
            }

            echo '<a href="' . URL . '/' . DIZIIZLEURL . '/' . $sef . '" class="hd">HD</a>
                    <a href="' . URL . '/' . DIZIIZLEURL . '/' . $sef . '"><img src="' . URL . '/images/jquery-film-ok.png" alt="Jquery film ok" class="jquery-film-ok" /></a>
                    <p class="jquery-film-yazi">' . $baslik . ' <br /></p>
                    </div>
                </li>';
        }
    } else {
        header("Location:" . URL . "/404");
        echo '<meta http-equiv="refresh" content="0;URL=' . URL . '/404">';
    }

    $conn->close();
}

function sezon_sayfa_ileri_geri() {
    $sef = @g("sef");
    $filmsayisi = FILMSAYISI;

    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $kat_query = $conn->query("SELECT * FROM dizisezon WHERE sef = '$sef'");
    $kat_array = $kat_query->fetch_assoc();
    $kat_id = $kat_array['id'];

    $sayfa = @intval(g("sayfa"));

    if (!$sayfa) {
        $sayfa = 1;
    }

    $geri = $sayfa - 1;
    $ileri = $sayfa + 1;

    if (!$sayfa || $sayfa == 0 || $sayfa == 1) {
        echo '<a href="#"><li class="sayfalama-geri">Geri</li></a>';
    } else {
        echo '<a href="' . URL . '/' . SEZONURL . '/' . $sef . '/' . $geri . '"><li class="sayfalama-geri">Geri</li></a>';
    }

    $query = $conn->query("SELECT * FROM diziler WHERE kategori LIKE '%$kat_id%'");
    $say = $query->num_rows;
    $bol = ceil($say / $filmsayisi);

    if ($bol == $sayfa) {
        echo '<a href="#"><li class="sayfalama-ileri">İleri</li></a>';
    } elseif ($bol < $sayfa) {
        echo '<a href="#"><li class="sayfalama-ileri">İleri</li></a>';
    } elseif (!$sayfa || $sayfa == 0 || $sayfa == 1) {
        echo '<a href="' . URL . '/' . SEZONURL . '/' . $sef . '/2"><li class="sayfalama-ileri">İleri</li></a>';
    } else {
        echo '<a href="' . URL . '/' . SEZONURL . '/' . $sef . '/' . $ileri . '"><li class="sayfalama-ileri">İleri</li></a>';
    }

    if ($sayfa > $bol) {
        if ($bol == 0) {
        } else {
            header("Location:" . URL . "/404");
            echo '<meta http-equiv="refresh" content="0;URL=' . URL . '/404">';
        }
    }

    $conn->close();
}

function sezon_sayfa() {
    $kat = @g("sef");
    $filmsayisi = FILMSAYISI;

    $conn = new mysqli("localhost", "root", "", "film");

    // Bağlantı hatası kontrolü
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }

    $kat_query = $conn->query("SELECT * FROM dizisezon WHERE sef = '$kat'");
    $kat_array = $kat_query->fetch_assoc();
    $kat_id = $kat_array['id'];

    $sayfa = @intval(g("sayfa"));

    if (!$sayfa) {
        $sayfa = 1;
    }

    $query = $conn->query("SELECT * FROM diziler WHERE kategori LIKE '%$kat_id%'");
    $say = $query->num_rows;
    $bol = ceil($say / $filmsayisi);

    $for_limit = 10;

    for ($i = $sayfa - $for_limit; $i < $sayfa + $for_limit; $i++) {
        if ($i > 0 && $i <= $bol) {
            if ($i == $sayfa) {
                echo '<li><a class="active"  href="' . URL . '/' . SEZONURL . '/' . $kat . '/' . $i . '">' . $i . '</a></li>';
            } else {
                echo '<li><a href="' . URL . '/' . SEZONURL . '/' . $kat . '/' . $i . '">' . $i . '</a></li>';
            }
        }
    }

    $conn->close();
}

  

   ?>