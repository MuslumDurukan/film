<?php 
/* db bağlantı */
require_once("../inc/baglan.php");

/* oturum kontrolu */

function oturum(){
if($_SESSION['admin'] != 1){
 header ("Location:index.php");
}
}
function doo() {
    oturum();
    $do = @$_GET['do'];
    
    switch ($do) {
        case "film_ekle":
            require_once "sayfa/filmekle.php";
            break;
            
        case "cache_sil":
            require_once "sayfa/cachesil.php";
            break;
            
        case "dizi_ekle":
            require_once "sayfa/dizi_ekle.php";
            break;
            
        case "cikis":
            require_once "sayfa/cikis.php";
            break;
            
        case "film_edit":
            require_once "sayfa/film_edit.php";
            break;
            
        case "film_sil":
            require_once "sayfa/film_sil.php";
            break;
            
        case "film_kategori_ekle":
            require_once "sayfa/film_kategori_ekle.php";
            break;
            
        case "film_duzenle":
            require_once "sayfa/film_duzenle.php";
            break;
            
        case "film_kategori_duzenle":
            require_once "sayfa/film_kategori_duzenle.php";
            break;
            
        case "film_kategori_edit":
            require_once "sayfa/film_kategori_edit.php";
            break;
            
        case "film_kategori_sil":
            require_once "sayfa/film_kategori_sil.php";
            break;
            
        case "dizi_duzenle":
            require_once "sayfa/dizi_duzenle.php";
            break;
            
        case "dizi_edit":
            require_once "sayfa/dizi_edit.php";
            break;
            
        case "dizi_sil":
            require_once "sayfa/dizi_sil.php";
            break;
            
        case "dizi_kat_ekle":
            require_once "sayfa/dizi_kat_ekle.php";
            break;
            
        case "dizi_kategori_duzenle":
            require_once "sayfa/dizi_kategori_duzenle.php";
            break;
            
        case "dizi_kategori_edit":
            require_once "sayfa/dizi_kategori_edit.php";
            break;
            
        case "dizi_kategori_sil":
            require_once "sayfa/dizi_kategori_sil.php";
            break;
            
        case "bozuk_film":
            require_once "sayfa/bozuk_film.php";
            break;

        case "bozuk_dizi":
            require_once "sayfa/bozuk_dizi.php";
            break;
            
        case "bozuk_dizi_sil":
            require_once "sayfa/bozuk_dizi_sil.php";
            break;
            
        case "bozuk_film_sil":
            require_once "sayfa/bozuk_film_sil.php";
            break;
            
        case "dizi_kategori_sezon_ekle":
            require_once "sayfa/dizi_kategori_sezon_ekle.php";
            break;
            
        case "dizi_kategori_sezon_duzenle":
            require_once "sayfa/dizi_kategori_sezon_duzenle.php";
            break;
            
        case "dizi_sezon_edit":
            require_once "sayfa/dizi_sezon_edit.php";
            break;
            
        case "dizi_sezon_sil":
            require_once "sayfa/dizi_sezon_sil.php";
            break;
            
        case "seo_ayarlari":
            require_once "sayfa/seo_ayarlari.php";
            break;
            
        default:
            require_once "sayfa/default.php";
            break;
    }
}
function filmekle() {
    $baglanti = mysqli_connect("localhost", "root", "", "film");

    if (!$baglanti) {
        die("Bağlantı hatası: " . mysqli_connect_error());
    }

    if (isset($_POST["post"])) {
        $veri = isset($_POST['kat']) ? $_POST['kat'] : array();
        $veri = array_map('intval', $veri);
        $kategori = implode(',', $veri);

        $isim = $_POST['isim'];
        $yapim = $_POST['yapim'];
        $yonetmen = $_POST['yonetmen'];
        $oyuncu = $_POST['oyuncu'];
        $embed = $_POST['embed'];
        $ozet = $_POST['ozet'];
        $manset = $_POST['manset'];
        $dil = $_POST['dil'];
        $title = $_POST['title'];
        $key = $_POST['key'];
        $desc = $_POST['desc'];
        $imdb = $_POST['imdb'];
        $sef = seola($isim) . '.html';

        $dosya_name = $_FILES["resim"]["type"];
        $dosya_ismi = $_FILES["resim"]["name"];
        $rand = rand(0, 99999999) . '-' . rand(0, 154752) . '-' . $dosya_ismi;
        $dosya_yolu = "../afis/" . $rand;

        if (in_array($dosya_name, ["image/jpeg", "image/png", "image/gif"])) {
            if (is_uploaded_file($_FILES['resim']["tmp_name"])) {
                $tasi = move_uploaded_file($_FILES['resim']['tmp_name'], $dosya_yolu);
                $resim_url = URL . '/afis/' . $rand;
            } else {
                echo "Dosya yükleme hatası!";
                return;
            }
        } else {
            echo "Geçersiz dosya formatı!";
            return;
        }

        $stmt = mysqli_prepare($baglanti, "INSERT INTO filmler (isim, sef, resim, yapim, yonetmen, oyuncu, ozet, imdb, dublaj, kategori, embed, title, description, keyw, manset) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "sssssssssssssss", $isim, $sef, $resim_url, $yapim, $yonetmen, $oyuncu, $ozet, $imdb, $dil, $kategori, $embed, $title, $desc, $key, $manset);
            $ekle = mysqli_stmt_execute($stmt);

            if ($ekle) {
                echo '
                <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>Başarılı!</strong> Film başarılı bir şekilde eklendi. F5 yapıyoruz.
                    <meta http-equiv="refresh" content="2;URL=' . URL . '/admin/panel.php?do=film_ekle">
                </div>';
            } else {
                echo "EKLEME BAŞARISIZ OLDU: " . mysqli_error($baglanti);
            }

            mysqli_stmt_close($stmt);
        } else {
            echo "Hazırlık hatası: " . mysqli_error($baglanti);
        }
    }
    
    mysqli_close($baglanti);
}
function film_duzenle() {
    // Bağlantıyı başlat
    $baglanti = mysqli_connect("localhost", "root", "", "film");

    if (!$baglanti) {
        die("Bağlantı hatası: " . mysqli_connect_error());
    }

    if (isset($_POST["post"])) {
        $veri = isset($_POST['kat']) ? $_POST['kat'] : array();
        $say = count($veri);

        // Güvenlik için veriyi filtreleyin
        $kategori = implode(',', array_map('intval', $veri)) . ',';

        $isim = $_POST['isim'];
        $yapim = $_POST['yapim'];
        $yonetmen = $_POST['yonetmen'];
        $oyuncu = $_POST['oyuncu'];
        $embed = $_POST['embed'];
        $ozet = $_POST['ozet'];
        $manset = $_POST['manset'];
        $dil = $_POST['dil'];
        $title = $_POST['title'];
        $keyw = $_POST['key'];
        $desc = $_POST['desc'];
        $imdb = $_POST['imdb'];
        $sef = $_POST['sef'];
        $id = $_POST['id'];

        $dosya_name = $_FILES["resim"]["type"];

        if (empty($dosya_name)) {
            $stmt = mysqli_prepare($baglanti, "UPDATE filmler SET isim = ?, yapim = ?, yonetmen = ?, oyuncu = ?, imdb = ?, embed = ?, ozet = ?, manset = ?, dublaj = ?, title = ?, keyw = ?, description = ?, sef = ?, kategori = ? WHERE id = ?");

            mysqli_stmt_bind_param($stmt, "ssssssssssssssi", $isim, $yapim, $yonetmen, $oyuncu, $imdb, $embed, $ozet, $manset, $dil, $title, $keyw, $desc, $sef, $kategori, $id);

            $guncelle = mysqli_stmt_execute($stmt);

            mysqli_stmt_close($stmt);
        } else {
            $dosya_ismi = $_FILES["resim"]["name"];
            $rand = rand(0, 99999999) . '-' . rand(0, 154752) . '-' . $dosya_ismi;
            $dosya_yolu = "../afis/" . $rand;

            if (in_array($dosya_name, ["image/jpeg", "image/png", "image/gif"])) {
                if (is_uploaded_file($_FILES['resim']["tmp_name"])) {
                    $tasi = move_uploaded_file($_FILES['resim']['tmp_name'], $dosya_yolu);
                    $resim_url = URL . '/afis/' . $rand;
                } else {
                    echo "Dosya yükleme hatası!";
                    return;
                }
            } else {
                echo "Geçersiz dosya formatı!";
                return;
            }

            $stmt = mysqli_prepare($baglanti, "UPDATE filmler SET isim = ?, yapim = ?, yonetmen = ?, oyuncu = ?, imdb = ?, embed = ?, ozet = ?, manset = ?, dublaj = ?, title = ?, keyw = ?, description = ?, sef = ?, kategori = ?, resim = ? WHERE id = ?");

            mysqli_stmt_bind_param($stmt, "sssssssssssssssi", $isim, $yapim, $yonetmen, $oyuncu, $imdb, $embed, $ozet, $manset, $dil, $title, $keyw, $desc, $sef, $kategori, $resim_url, $id);

            $guncelle = mysqli_stmt_execute($stmt);

            mysqli_stmt_close($stmt);
        }

        if ($guncelle) {
            echo '
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>Başarılı!</strong> Film başarılı bir şekilde güncellendi. F5 yapıyoruz.
                <meta http-equiv="refresh" content="2;URL=' . URL . '/admin/panel.php?do=film_edit&id=' . $id . '">
            </div>';
        } else {
            echo "Güncelleme hatası: " . mysqli_error($baglanti);
        }
    }

    // Bağlantıyı kapat
    mysqli_close($baglanti);
}
function seola($s) {

$tr = array('ş','Ş','ı','İ','ğ','Ğ','ü','Ü','ö','Ö','Ç','ç');

$eng = array('s','s','i','i','g','g','u','u','o','o','c','c');

$s = str_replace($tr,$eng,$s);

$s = strtolower($s);

$s = preg_replace('/&.+?;/', '', $s);

$s = preg_replace('/[^%a-z0-9 _-]/', '', $s);

$s = preg_replace('/\s+/', '-', $s);

$s = preg_replace('|-+|', '-', $s);

$s = trim($s, '-');

 

return $s.'-'.rand(0,100);

}
function kategori_ekle(){
    if(isset($_POST["post"])){
        $kategoriseo = $_POST['kategoriseo'];
        $kategori = $_POST['kategori'];
        $title = $_POST['title'];
        $key = $_POST['key'];
        $desc = $_POST['desc'];

        if(empty($kategoriseo)){
            $kategoriseo = seola($kategori);
        }

        // Bağlantıyı başlat
        $conn = mysqli_connect("localhost", "root", "", "film");

        if (!$conn) {
            die("Bağlantı hatası: " . mysqli_connect_error());
        }

        // SQL injection önleme: Hazırlıklı ifade kullanma
        $stmt = mysqli_prepare($conn, "INSERT INTO kategori (kat_seo, kat_isim, title, keyw, description) VALUES (?, ?, ?, ?, ?)");

        if ($stmt) {
            // Bind parameters
            mysqli_stmt_bind_param($stmt, "sssss", $kategoriseo, $kategori, $title, $key, $desc);

            // Execute the statement
            $ekle = mysqli_stmt_execute($stmt);

            // Close the statement
            mysqli_stmt_close($stmt);

            if($ekle){
                echo '
                <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>Başarılı!</strong> Kategori başarılı bir şekilde Eklendi. F5 yapıyoruz.
                    <meta http-equiv="refresh" content="2;URL='.URL.'/admin/panel.php?do=film_kategori_ekle">
                </div>';
            } else {
                echo "Ekleme hatası: " . mysqli_error($conn);
            }
        } else {
            echo "Hazırlıklı ifade hatası: " . mysqli_error($conn);
        }

        // Bağlantıyı kapat
        mysqli_close($conn);
    }
}
function film_kategori_duzenle() {
    if (isset($_POST['kategoriseo']) && isset($_POST['kategori']) && isset($_POST['title']) && isset($_POST['key']) && isset($_POST['desc'])) {
        $id = $_GET['id'];
        $kategoriseo = $_POST['kategoriseo'];
        $kategori = $_POST['kategori'];
        $title = $_POST['title'];
        $key = $_POST['key'];
        $desc = $_POST['desc'];

        // Bağlantıyı başlat
        $conn = mysqli_connect("localhost", "root", "", "film");

        if (!$conn) {
            die("Bağlantı hatası: " . mysqli_connect_error());
        }

        // SQL injection önleme: Hazırlıklı ifade kullanma
        $stmt = mysqli_prepare($conn, "UPDATE kategori SET kat_isim = ?, kat_seo = ?, title = ?, keyw = ?, description = ? WHERE id = ?");

        if ($stmt) {
            // Bind parameters
            mysqli_stmt_bind_param($stmt, "sssssi", $kategori, $kategoriseo, $title, $key, $desc, $id);

            // Execute the statement
            $guncelle = mysqli_stmt_execute($stmt);

            // Close the statement
            mysqli_stmt_close($stmt);

            if ($guncelle) {
                echo '<div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>Başarılı!</strong> Kategori başarılı bir şekilde Güncellendi. F5 yapıyoruz.
                    <meta http-equiv="refresh" content="2;URL=' . URL . '/admin/panel.php?do=film_kategori_edit&id=' . $id . '">
                </div>';
            } else {
                echo "Güncelleme hatası: " . mysqli_error($conn);
            }
        } else {
            echo "Hazırlıklı ifade hatası: " . mysqli_error($conn);
        }

        // Bağlantıyı kapat
        mysqli_close($conn);
    } else {
        echo "POST verileri eksik!";
    }
}
function diziekle() {
    if (isset($_POST["post"])) { // Formun "post" adlı butona basıldığını kontrol edin
        $isim = $_POST['isim'];
        $kat = $_POST['kat'];
        $embed = $_POST['embed'];
        $ozet = $_POST['ozet'];
        $dil = $_POST['dil'];
        $title = $_POST['title'];
        $key = $_POST['key'];
        $desc = $_POST['desc'];
        $sef = seola($isim) . '.html';

        $conn = mysqli_connect("localhost", "root", "", "film");

        if (!$conn) {
            die("Bağlantı hatası: " . mysqli_connect_error());
        }

        // Dosya yükleme işlemi
        $dosya_name = $_FILES["resim"]["type"];
        $dosya_ismi = $_FILES["resim"]["name"];
        $rand = rand(0, 99999999) . '-' . rand(0, 154752) . '-' . $dosya_ismi;
        $dosya_yolu = "../afis/" . $rand;

        // Dosya türünü kontrol et
        if ($dosya_name == "image/jpeg" || $dosya_name == "image/png" || $dosya_name == "image/gif") {
            if (is_uploaded_file($_FILES['resim']["tmp_name"])) {
                $tasi = move_uploaded_file($_FILES['resim']['tmp_name'], $dosya_yolu);
                $resim_url = URL . '/afis/' . $rand;
            } else {
                echo "Dosya yükleme hatası!";
                return;
            }
        } else {
            echo "Geçersiz dosya formatı!";
            return;
        }

        // Hazırlıklı ifade kullanarak SQL injection'ı önle
        $stmt = mysqli_prepare($conn, "INSERT INTO diziler (isim, sef, resim, ozet, dublaj, kategori, embed, title, description, keyw) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        if ($stmt) {
            // Değişkenleri bağla
            mysqli_stmt_bind_param($stmt, "ssssssssss", $isim, $sef, $resim_url, $ozet, $dil, $kat, $embed, $title, $desc, $key);

            // İfadeyi çalıştır
            $ekle = mysqli_stmt_execute($stmt);

            if ($ekle) {
                echo '
                <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>Başarılı!</strong> Dizi başarılı bir şekilde eklendi. F5 yapıyoruz.
                    <meta http-equiv="refresh" content="2;URL='.URL.'/admin/panel.php?do=dizi_ekle">
                </div>';
            } else {
                echo "Error: " . mysqli_stmt_error($stmt);
            }

            // İfadeyi kapat
            mysqli_stmt_close($stmt);
        } else {
            echo "Error: " . mysqli_error($conn);
        }

        // Bağlantıyı kapat
        mysqli_close($conn);
    }
}
function dizi_duzenle() {
    if (isset($_POST["post"])) {
        $isim = $_POST['isim'];
        $kat = $_POST['kat'];
        $embed = $_POST['embed'];
        $ozet = $_POST['ozet'];
        $dil = $_POST['dil'];
        $title = $_POST['title'];
        $keyw = $_POST['key'];
        $desc = $_POST['desc'];
        $seo = $_POST['seo'];
        $dosya_name = $_FILES["resim"]["type"];
        $id = $_GET['id'];

        $conn = mysqli_connect("localhost", "root", "", "film");

        if (!$conn) {
            die("Bağlantı hatası: " . mysqli_connect_error());
        }

        // Dosya yükleme işlemi
        if (!empty($dosya_name)) {
            $dosya_ismi = $_FILES["resim"]["name"];
            $rand = rand(0, 99999999) . '-' . rand(0, 154752) . '-' . $dosya_ismi;
            $dosya_yolu = "../afis/" . $rand;

            // Dosya türünü kontrol et
            if ($dosya_name == "image/jpeg" || $dosya_name == "image/png" || $dosya_name == "image/gif") {
                if (is_uploaded_file($_FILES['resim']["tmp_name"])) {
                    $tasi = move_uploaded_file($_FILES['resim']['tmp_name'], $dosya_yolu);
                    $resim_url = URL . '/afis/' . $rand;
                } else {
                    echo "Dosya yükleme hatası!";
                    return;
                }
            } else {
                echo "Geçersiz dosya formatı!";
                return;
            }
        }

        // Hazırlıklı ifade kullanarak SQL injection'ı önle
        if (!empty($dosya_name)) {
            $stmt = mysqli_prepare($conn, "UPDATE diziler SET isim=?, embed=?, ozet=?, dublaj=?, title=?, keyw=?, description=?, sef=?, kategori=?, resim=? WHERE id=?");
            mysqli_stmt_bind_param($stmt, "ssssssssssi", $isim, $embed, $ozet, $dil, $title, $keyw, $desc, $seo, $kat, $resim_url, $id);
        } else {
            $stmt = mysqli_prepare($conn, "UPDATE diziler SET isim=?, embed=?, ozet=?, dublaj=?, title=?, keyw=?, description=?, sef=?, kategori=? WHERE id=?");
            mysqli_stmt_bind_param($stmt, "sssssssssi", $isim, $embed, $ozet, $dil, $title, $keyw, $desc, $seo, $kat, $id);
        }

        $guncelle = mysqli_stmt_execute($stmt);

        mysqli_close($conn);

        if ($guncelle) {
            echo '
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>Başarılı!</strong> Dizi başarılı bir şekilde güncellendi. F5 yapıyoruz.
                <meta http-equiv="refresh" content="2;URL='.URL.'/admin/panel.php?do=dizi_edit&id='.$id.'">
            </div>';
        } else {
            echo "Error: " . mysqli_stmt_error($stmt);
        }
    }
}
function dizi_kategori_ekle() {
    if (isset($_POST["post"])) {
        $kategoriseo = $_POST['kategoriseo'];
        $kategori = $_POST['kategori'];
        $title = $_POST['title'];
        $key = $_POST['key'];
        $desc = $_POST['desc'];

        if (empty($kategoriseo)) {
            $kategoriseo = seola($kategori);
        }

        $conn = mysqli_connect("localhost", "root", "", "film");

        if (!$conn) {
            die("Bağlantı hatası: " . mysqli_connect_error());
        }

        // Hazırlıklı ifade kullanarak SQL injection'ı önle
        $stmt = mysqli_prepare($conn, "INSERT INTO dizikat (kat_seo, kat_isim, title, keyw, description) VALUES (?, ?, ?, ?, ?)");

        if ($stmt) {
            // Parametreleri bağla
            mysqli_stmt_bind_param($stmt, "sssss", $kategoriseo, $kategori, $title, $key, $desc);

            // İfadenin çalıştırılması
            if (mysqli_stmt_execute($stmt)) {
                echo '
                <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>Başarılı!</strong> Dizi Kategorisi başarılı bir şekilde Eklendi. F5 yapıyoruz.
                    <meta http-equiv="refresh" content="2;URL='.URL.'/admin/panel.php?do=film_kategori_ekle">
                </div>';
            } else {
                echo "Hata: " . mysqli_stmt_error($stmt);
            }

            // İfadeyi kapat
            mysqli_stmt_close($stmt);
        } else {
            echo "Hazırlıklı ifade hatası: " . mysqli_error($conn);
        }

        // Bağlantıyı kapat
        mysqli_close($conn);
    }
}
function dizi_kategori_duzenle() {
    if (isset($_POST["post"])) {
        $id = $_GET['id'];
        $kategoriseo = $_POST['kategoriseo'];
        $kategori = $_POST['kategori'];
        $title = $_POST['title'];
        $key = $_POST['key'];
        $desc = $_POST['desc'];

        $conn = mysqli_connect("localhost", "root", "", "film");

        if (!$conn) {
            die("Bağlantı hatası: " . mysqli_connect_error());
        }

        // Hazırlıklı ifade kullanarak SQL injection'ı önle
        $stmt = mysqli_prepare($conn, "UPDATE dizikat SET kat_isim = ?, kat_seo = ?, title = ?, keyw = ?, description = ? WHERE id = ?");

        if ($stmt) {
            // Parametreleri bağla
            mysqli_stmt_bind_param($stmt, "sssssi", $kategori, $kategoriseo, $title, $key, $desc, $id);

            // İfadenin çalıştırılması
            if (mysqli_stmt_execute($stmt)) {
                echo '
                <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>Başarılı!</strong> Dizi Kategorisi başarılı bir şekilde Güncellendi. F5 yapıyoruz.
                    <meta http-equiv="refresh" content="2;URL='.URL.'/admin/panel.php?do=dizi_kategori_edit&id='.$id.'">
                </div>';
            } else {
                echo "Hata: " . mysqli_stmt_error($stmt);
            }

            // İfadeyi kapat
            mysqli_stmt_close($stmt);
        } else {
            echo "Hazırlıklı ifade hatası: " . mysqli_error($conn);
        }

        // Bağlantıyı kapat
        mysqli_close($conn);
    }
}
function dizi_kategori_sezon_ekle() {
    if(isset($_POST["post"])) {
        $seo = @$_POST['kategoriseo'];
        $kategori = @$_POST['kat'];
        $title = @$_POST['title'];
        $key = @$_POST['key'];
        $desc = @$_POST['desc'];
        $isim = @$_POST['isim'];

        if (!$seo) {
            $seo = seola($isim);
        }

        // Bağlantıyı başlat
        $conn = mysqli_connect("localhost", "root", "", "film");

        if (!$conn) {
            die("Bağlantı hatası: " . mysqli_connect_error());
        }

        // "resim" indexinin $_FILES içinde ayarlı olup olmadığını kontrol et
        if (isset($_FILES["resim"])) {
            $dosya_name = $_FILES["resim"]["type"];
            $eski_resim_url = @$_POST['eski_resim_url'];

            if (!$kategori) {
                echo '<div class="alert alert-error">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>BAŞARISIZ!</strong> Lütfen kategori seçiniz.
                      </div>';
            } else {
                // "resim" indexinin $_FILES içinde ayarlı olup olmadığını kontrol et
                if (isset($_FILES["resim"])) {
                    $dosya_name = $_FILES["resim"]["type"];
                    $eski_resim_url = @$_POST['eski_resim_url'];

                    if (!$eski_resim_url && !$dosya_name) {
                        echo '<div class="alert alert-error">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>BAŞARISIZ!</strong> Lütfen resim seçiniz.
                              </div>';
                    } else {
                        if ($eski_resim_url) {
                            $ekle = mysqli_query($conn, "INSERT INTO dizisezon (sezonisim, dizikatid, resim_url, sef, title, keyw, description) VALUES ('$isim', '$kategori', '$eski_resim_url', '$seo', '$title', '$key', '$desc')");
                        } elseif ($dosya_name) {
                            // Geri kalan dosya yükleme kodunuz burada olmalıdır
                            $dosya_ismi = $_FILES["resim"]["name"];
                            $rand = rand(0, 99999999) . '-' . rand(0, 154752) . '-' . $dosya_ismi;
                            $dosya_yolu = "../afis/" . $rand;

                            if ($dosya_name == "image/jpeg" || $dosya_name == "image/png" || $dosya_name == "image/gif") {
                                if (is_uploaded_file($_FILES['resim']["tmp_name"])) {
                                    $tasi = move_uploaded_file($_FILES['resim']['tmp_name'], $dosya_yolu);
                                    $resim_url = URL . '/afis/' . $rand;

                                    $ekle = mysqli_query($conn, "INSERT INTO dizisezon (sezonisim, dizikatid, resim_url, sef, title, keyw, description) VALUES ('$isim', '$kategori', '$resim_url', '$seo', '$title', '$key', '$desc')");
                                } else {
                                    echo "Dosya yükleme hatası!";
                                }
                            } else {
                                echo "Geçersiz dosya formatı!";
                            }
                        }

                        if ($ekle) {
                            echo '<div class="alert alert-success">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong>Başarılı!</strong> Dizi Kategorisi başarılı bir şekilde Güncellendi. F5 yapıyoruz.
                                    <meta http-equiv="refresh" content="2;URL='.URL.'/admin/panel.php?do=dizi_kategori_sezon_ekle">
                                  </div>';
                        } else {
                            echo "Error: " . mysqli_error($conn);
                        }
                    }
                }
            }
        }

        // Bağlantıyı kapat
        mysqli_close($conn);
    }
}
function seo_ayarlari_duzenle() {
    if (isset($_POST["post"])) {
        $siteurl = $_POST['siteurl'];
        $anatitle = $_POST['anatitle'];
        $anadesc = $_POST['anadesc'];
        $anakey = $_POST['anakey'];
        $filmtitle = $_POST['filmtitle'];
        $filmdesc = $_POST['filmdesc'];
        $filmkey = $_POST['filmkey'];
        $kattitle = $_POST['kattitle'];
        $katdesc = $_POST['katdesc'];
        $katkey = $_POST['katkey'];
        $begentitle = $_POST['begentitle'];
        $begendesc = $_POST['begendesc'];
        $begenkey = $_POST['begenkey'];
        $hukuktitle = $_POST['hukuktitle'];
        $hukukdesc = $_POST['hukukdesc'];
        $hukukkey = $_POST['hukukkey'];
        $trtitle = $_POST['trtitle'];
        $trdesc = $_POST['trdesc'];
        $trkey = $_POST['trkey'];
        $dizititle = $_POST['dizititle'];
        $dizidesc = $_POST['dizidesc'];
        $dizikey = $_POST['dizikey'];
        $sezontitle = $_POST['sezontitle'];
        $sezondesc = $_POST['sezondesc'];
        $sezonkey = $_POST['sezonkey'];
        $dizifilmtitle = $_POST['dizifilmtitle'];
        $dizifilmdesc = $_POST['dizifilmdesc'];
        $dizifilmkey = $_POST['dizifilmkey'];

        // Bağlantıyı başlat
        $conn = mysqli_connect("localhost", "root", "", "film");

        if (!$conn) {
            die("Bağlantı hatası: " . mysqli_connect_error());
        }

        // Security: Use prepared statements
        $stmt = mysqli_prepare($conn, "UPDATE seo SET 
            site_url = ?,
            ana_title = ?,
            ana_desc = ?,
            ana_key = ?,
            title = ?,
            description = ?,
            keywords = ?,
            kat_title = ?,
            kat_key = ?,
            kat_desc = ?,
            begen_title = ?,
            begen_key = ?,
            begen_desc = ?,
            hukuk_title = ?,
            hukuk_key = ?,
            hukuk_desc = ?,
            tr_title = ?,
            tr_desc = ?,
            tr_key = ?,
            dizi_title = ?,
            dizi_key = ?,
            dizi_desc = ?,
            sezon_title = ?,
            sezon_key = ?,
            sezon_desc = ?,
            dizle_title = ?,
            dizle_key = ?,
            dizle_desc = ?
        ");

        if (!$stmt) {
            die("Query preparation failed: " . mysqli_error($conn));
        }

        // Bind parameters and execute
        mysqli_stmt_bind_param($stmt, "ssssssssssssssssssssssssssssssss",
            $siteurl, $anatitle, $anadesc, $anakey, $filmtitle, $filmdesc, $filmkey,
            $kattitle, $katkey, $katdesc, $begentitle, $begenkey, $begendesc,
            $hukuktitle, $hukukkey, $hukukdesc, $trtitle, $trdesc, $trkey,
            $dizititle, $dizikey, $dizidesc, $sezontitle, $sezonkey, $sezondesc,
            $dizifilmtitle, $dizifilmkey, $dizifilmdesc
        );

        $guncelle = mysqli_stmt_execute($stmt);

if ($guncelle) {
    $etkilenenSatirSayisi = mysqli_affected_rows($conn);

    if ($etkilenenSatirSayisi > 0) {
        echo '<div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>Başarılı!</strong> Seo ayarları başarılı bir şekilde kaydedildi. F5 yapıyoruz.
                <meta http-equiv="refresh" content="2;URL='.URL.'/admin/panel.php?do=seo_ayarlari">
              </div>';
    } else {
        echo '<div class="alert alert-warning">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>Uyarı!</strong> Herhangi bir değişiklik yapılmadı.
              </div>';
    }
} else {
    echo '<div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>Hata!</strong> Seo ayarları güncellenirken bir hata oluştu: ' . mysqli_error($conn) . '
          </div>';
}

// Close statement and connection
mysqli_stmt_close($stmt);
mysqli_close($conn);
    }
}

?>