<?php

$id = $_GET['id'];

$baglan = new mysqli("localhost", "root", "", "film");

if ($baglan->connect_error) {
    die("Bağlantı hatası: " . $baglan->connect_error);
}

$bul = $baglan->query("SELECT * FROM dizisezon WHERE id = '$id'");

$row = $bul->fetch_assoc();

$isim = $row['sezonisim'];
$sef = $row['sef'];
$title = $row['title'];
$key = $row['keyw'];
$desc = $row['description'];
$resimurl = $row['resim_url'];
$dizikatid = $row['dizikatid'];

/* Güncelle */

if ($_POST) {
    $seo = $_POST['kategoriseo'];
    $kategori = $_POST['kat'];
    $title = $_POST['title'];
    $key = $_POST['key'];
    $desc = $_POST['desc'];
    $isim = $_POST['isim'];
    $dosya_name = $_FILES["resim"]["type"];
    $eski_resim_url = @$_POST['eski_resim_url'];

    if (!$kategori) {
        echo '<div class="alert alert-error"><button type="button" class="close" data-dismiss="alert">×</button><strong>BAŞARISIZ!</strong> Lütfen kategori seçiniz.	</div>';
    } else {
        if ($eski_resim_url != $resimurl) {
            $guncelle = $baglan->query("UPDATE dizisezon SET sezonisim = '$isim' , sef = '$seo', dizikatid='$kategori',resim_url='$eski_resim_url',keyw='$key',description = '$desc' ,title = '$title' WHERE id = '$id'");
        } elseif ($dosya_name) {
            $dosya_name = $_FILES["resim"]["type"];
            $dosya_ismi = $_FILES["resim"]["name"];
            $rand = rand(0, 99999999) . '-' . rand(0, 154752) . '-' . $dosya_ismi;
            $dosya_yolu = "../afis/" . $rand;

            if ($dosya_name == "image/jpeg" || $dosya_name == "image/png" || $dosya_name == "image/gif") {
                if (is_uploaded_file($_FILES['resim']["tmp_name"])) {
                    $tasi = move_uploaded_file($_FILES['resim']['tmp_name'], $dosya_yolu);
                    $resim_url = URL . '/afis/' . $rand;
                }
            }

            $guncelle = $baglan->query("UPDATE dizisezon SET sezonisim = '$isim' , sef = '$seo', dizikatid='$kategori',resim_url='$resim_url',keyw='$key',description = '$desc' ,title = '$title' WHERE id = '$id'");
        } elseif ($eski_resim_url == $resimurl) {
            $guncelle = $baglan->query("UPDATE dizisezon SET sezonisim = '$isim' , sef = '$seo', dizikatid='$kategori',resim_url='$eski_resim_url',keyw='$key',description = '$desc' ,title = '$title' WHERE id = '$id'");
        }

        if ($guncelle) {
            echo '<div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>Başarılı!</strong> Dizi Kategorisi başarılı bir şekilde Güncellendi. Sayfa yenileniyor.
                <meta http-equiv="refresh" content="2;URL=' . URL . '/admin/panel.php?do=dizi_sezon_edit&id=' . $id . '">
            </div>';
        }
    }
}

$baglan->close();
?>

<div class="row-fluid sortable">

				<div class="box span12"><div class="box-header well" data-original-title>

						<h2><i class="icon-edit"></i> Dizi Kategori Sezon Düzenle</h2>

						<div class="box-icon">

							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>

							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>

							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>

						</div>

					</div>

		<div class="box-content">

						<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">

							<fieldset>

							  <div class="control-group">

								<label class="control-label" for="focusedInput">Sezon Adı:</label>

								<div class="controls">

								  <input class="input-xlarge focused" value="<?php echo $isim; ?>" name="isim" id="focusedInput" type="text" />

								</div>

							  </div>





							  <div class="control-group">

								<label class="control-label" for="focusedInput">Sezon Seo:</label>

								<div class="controls">

								  <input class="input-xlarge focused" value="<?php echo $sef; ?>" name="kategoriseo" id="focusedInput" type="text" />

								</div>

							  </div>

						

				

				 <div class="control-group">

								<label class="control-label" for="focusedInput">Sezon Dizi Kat.</label>

								<div class="controls">

								  <select name="kat" id="selectError1" multiple data-rel="chosen">

								  <?php 

								    $bul = mysql_query("select * from dizikat");

								    while($row = mysql_fetch_array($bul)){

									$id = $row['id'];

									$sezon_isim = $row['kat_isim'];

									if($id == $dizikatid){echo ' <option selected value="'.$id.'" >'.$sezon_isim.'</option>';}

									else{

									echo ' <option  value="'.$id.'" >'.$sezon_isim.'</option>';}

									}

								  ?>

								  </select>

					</div></div>



							



							  <div class="control-group">

								<label class="control-label" for="focusedInput">Title:</label>

								<div class="controls">

								  <input class="input-xlarge focused" value="<?php echo $title; ?>" name="title" id="focusedInput" type="text" />

								</div>

							  </div>

						 <div class="control-group">

								<label class="control-label" for="focusedInput">Keyword:</label>

								<div class="controls">

								  <input class="input-xlarge focused" value="<?php echo $key; ?>" name="key" id="focusedInput" type="text" />

								</div>

							  </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Description:</label>

								<div class="controls">

								  <input class="input-xlarge focused" value="<?php echo $desc; ?>" name="desc" id="focusedInput" type="text" />

								</div>

							  </div>

							 <div class="control-group">

								<label class="control-label">Resim Ekle</label>

								<div class="controls">

								  <input name="resim" type="file">

								</div>

							  </div>

							   <div class="control-group">

								<label class="control-label" for="focusedInput">Resim URL</label>

								<div class="controls">

								 <input class="input-xlarge focused" value="<?php echo $resimurl; ?>" name="eski_resim_url" id="focusedInput" type="text" />

					</div></div>

							  <div class="form-actions">

								<input type="submit" name="post" value="Kategori Düzenle" class="btn btn-primary"/>

							  </div>

							</fieldset>

						  </form>

				

					</div>

				</div>	</div>

				</div>

								