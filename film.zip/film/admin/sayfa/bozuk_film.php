<div class="row-fluid sortable">		
				<div class="box span12">
					<div class="box-header well" data-original-title>
						<h2><i class="icon-user"></i> Bozuk Filmler</h2>
						<div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>ID</th>
								  <th>Film İsmi</th>
								  <th>Yapılacaklar</th>
							  </tr>
						  </thead>   
						  <tbody>
<?php 
// MySQL bağlantısı oluşturun, uygun bilgileri girin
$baglan = new mysqli("localhost", "root", "", "film");

// Bağlantı hatasını kontrol edin
if ($baglan->connect_error) {
    die("Bağlantı hatası: " . $baglan->connect_error);
}

// Sorguyu hazırlayın ve çalıştırın
$film_cek = $baglan->query("SELECT * FROM bozukfilm ORDER BY ID");

while ($row = $film_cek->fetch_assoc()) {
    $film_id = $row['film_id'];
    $isim = $row['film_isim'];
    $seo = $row['film_seo'];
    $id = $row['id'];

    echo '<tr>
            <td>' . $id . '</td>
            <td class="center">' . $isim . '</td>
        
            <td class="center">
                <a class="btn btn-success" target="_blank" href="' . URL . '/' . FILMURL . '/' . $seo . '">
                    <i class="icon-zoom-in icon-white"></i>  
                    Filme Bak                                        
                </a>
                <a class="btn btn-info" target="_blank" href="panel.php?do=film_edit&id=' . $film_id . '">
                    <i class="icon-edit icon-white"></i>  
                    Edit                                            
                </a>
                <a class="btn btn-danger" href="panel.php?do=bozuk_film_sil&id=' . $id . '" target="_blank" >
                    <i class="icon-trash icon-white"></i> 
                    Delete
                </a>
            </td>
        </tr>';
}

// MySQL bağlantısını kapatın
$baglan->close();
?>
							
							
									  </tbody>
					  </table>            
					</div>
				</div><!--/span-->
			
			</div>