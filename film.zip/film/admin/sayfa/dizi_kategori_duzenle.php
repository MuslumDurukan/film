<div class="row-fluid sortable">		
				<div class="box span12">
					<div class="box-header well" data-original-title>
						<h2><i class="icon-user"></i> Diziler</h2>
						<div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>ID</th>
								  <th>Kategori İsmi</th>
								  <th>Yapılacaklar</th>
							  </tr>
						  </thead>   
						  <tbody>
<?php 
$baglan = new mysqli("localhost", "root", "", "film");

if ($baglan->connect_error) {
    die("Bağlantı hatası: " . $baglan->connect_error);
}

$query = "SELECT * FROM dizikat ORDER BY ID";
$result = $baglan->query($query);

while ($row = $result->fetch_assoc()) {
    $id    = $row['id'];
    $isim  = $row['kat_isim'];
    $seo   = $row['kat_seo'];

    echo '<tr>
        <td>' . $id . '</td>
        <td class="center">' . $isim . '</td>
        <td class="center">
            <a class="btn btn-success" target="_blank" href="' . URL . '/' . DIZIKATURL . '/' . $seo . '">
                <i class="icon-zoom-in icon-white"></i>  
                Kategoriye Bak                                         
            </a>
            <a class="btn btn-info" href="panel.php?do=dizi_kategori_edit&id=' . $id . '">
                <i class="icon-edit icon-white"></i>  
                Edit                                            
            </a>
            <a class="btn btn-danger" href="panel.php?do=dizi_kategori_sil&id=' . $id . '" target="_blank">
                <i class="icon-trash icon-white"></i> 
                Delete
            </a>
        </td>
    </tr>';
}

$baglan->close();
?>
									  </tbody>
					  </table>            
					</div>
				</div><!--/span-->
			
			</div>