<div class="row-fluid sortable">
				<div class="box span12"><div class="box-header well" data-original-title>
						<h2><i class="icon-edit"></i> Cache Sil</h2>
						<div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
		<div class="box-content">
<iframe src="<?php echo URL; ?>/cachesil.php" width="600" height="200" frameborder=0 />

</div>
</div>
</div>