	<div class="row-fluid">
				<div class="box span12">
					<div class="box-header well">
						<h2><i class="icon-info-sign"></i>Bilgilendirme</h2>
						<div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					<div class="box-content">
					<p>Ana sayfamız boş kalmasın diye hazırladığımız bir bölüm buraya eklediğimiz iframe ile gelecek güncellemeleri ve yenilikleri otomatik olarak görebileceksiniz...</p>
					
					
						
					
						<div class="clearfix"></div>
					</div>
				</div>
			</div>