<?php 
session_start();
session_destroy();
$yonlen = URL.'/admin/index.php';

echo "<meta content='0; URL=$yonlen' http-equiv='refresh'>";
?>
