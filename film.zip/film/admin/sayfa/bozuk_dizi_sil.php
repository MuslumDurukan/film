<?php 
// MySQL bağlantısı oluşturun, uygun bilgileri girin
$baglan = new mysqli("localhost", "root", "", "film");

// Bağlantı hatasını kontrol edin
if ($baglan->connect_error) {
    die("Bağlantı hatası: " . $baglan->connect_error);
}

// id parametresini güvenli bir şekilde alın
$id = isset($_GET['id']) ? $baglan->real_escape_string($_GET['id']) : '';

// Sorguyu hazırlayın ve çalıştırın
$sil = $baglan->query("DELETE FROM bozukdizi WHERE id='$id' ");

if ($sil) {
    echo '<script language="javascript">
        $(function(){
            var saniye = 3;
            $.geriyeSay = function(){
                if (saniye > 1){
                    saniye--;
                } else {
                    window.close();
                }
            }
            setInterval("$.geriyeSay()", 1000);
        });
    </script>';
}

// MySQL bağlantısını kapatın
$baglan->close();
?><div class="row-fluid">
				<div class="box span12">
					<div class="box-header well">
						<h2><i class="icon-info-sign"></i>Bozuk Dizi Silme</h2>
						<div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					<div class="box-content">
					<p><font color="red">Bozuk Dizi Başarılı Bir şekilde silindi</font></p>
					
