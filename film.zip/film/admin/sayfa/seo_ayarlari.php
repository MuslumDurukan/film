<?php
$mysqli = new mysqli("localhost", "root", "", "film");

// Bağlantı hatası kontrolü
if ($mysqli->connect_error) {
    die("Bağlantı hatası: " . $mysqli->connect_error);
}

$bulSorgu = $mysqli->query("SELECT * FROM seo WHERE id = '1'");

// Sorgu sonucu kontrolü
if ($bulSorgu) {
    $row = $bulSorgu->fetch_assoc();

    // Daha fazla işlem yapabilirsiniz...

    $bulSorgu->close(); // Sorgu sonuç nesnesini kapat
} else {
    echo "Sorgu hatası: " . $mysqli->error;
}

$mysqli->close();
?>



<div class="row-fluid sortable">

				<div class="box span12"><div class="box-header well" data-original-title>

						<h2><i class="icon-edit"></i> Seo Ayarları</h2>

						<div class="box-icon">

							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>

							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>

							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>

						</div>

					</div>

		<div class="box-content">

						<form class="form-horizontal" action="panel.php?do=seo_ayarlari" method="post" enctype="multipart/form-data">

							<fieldset>

							  <div class="control-group">

								<label class="control-label" for="focusedInput">Site İsmi:</label>

								<div class="controls">

								  <input class="input-xlarge focused" value="<?php echo $row['site_url']; ?>" name="siteurl" id="focusedInput" type="text" />

								</div>

							  </div>

				             <div class="control-group">

								<label class="control-label" for="focusedInput">Ana Sayfa Title</label>

								<div class="controls">

								  <input class="input-xlarge focused" value="<?php echo $row['ana_title']; ?>" name="anatitle" id="focusedInput" type="text" />

								</div>

							  </div>

	                     	<div class="control-group">

								<label class="control-label" for="focusedInput">Ana Sayfa Desc</label>

								<div class="controls">

								  <input class="input-xlarge focused" value="<?php echo $row['ana_desc']; ?>" name="anadesc" id="focusedInput" type="text" />

								</div>

							  </div>

							<div class="control-group">

								<label class="control-label" for="focusedInput">Ana Sayfa Key</label>

								<div class="controls">

								  <input class="input-xlarge focused" name="anakey" value="<?php echo $row['ana_key']; ?>" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Film Title</label>

								<div class="controls">

								  <input class="input-xlarge focused" value="<?php echo $row['title']; ?>" name="filmtitle" id="focusedInput" type="text" />

								</div>

							 </div>

						  <div class="control-group">

								<label class="control-label" for="focusedInput">Film Desc</label>

								<div class="controls">

								  <input class="input-xlarge focused" value="<?php echo $row['description']; ?>" name="filmdesc" id="focusedInput" type="text" />

								</div>

							 </div>

					      <div class="control-group">

								<label class="control-label" for="focusedInput">Film Key</label>

								<div class="controls">

								  <input class="input-xlarge focused"  value="<?php echo $row['keywords']; ?>" name="filmkey" id="focusedInput" type="text" />

								</div>

							 </div>

							  <div class="control-group">

								<label class="control-label" for="focusedInput">Kat Title</label>

								<div class="controls">

								  <input class="input-xlarge focused" value="<?php echo $row['kat_title']; ?>" name="kattitle" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Kat Desc</label>

								<div class="controls">

								  <input class="input-xlarge focused" name="katdesc" value="<?php echo $row['kat_desc']; ?>" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Kat Key</label>

								<div class="controls">

								  <input class="input-xlarge focused" name="katkey" value="<?php echo $row['kat_key']; ?>" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Beğen Title</label>

								<div class="controls">

								  <input class="input-xlarge focused" name="begentitle" value="<?php echo $row['begen_title']; ?>" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Beğen desc</label>

								<div class="controls">

								  <input class="input-xlarge focused" name="begendesc" value="<?php echo $row['begen_desc']; ?>" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Beğen Key</label>

								<div class="controls">

								  <input class="input-xlarge focused" name="begenkey"  value="<?php echo $row['begen_key']; ?>" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Hukuk Title</label>

								<div class="controls">

								  <input class="input-xlarge focused" name="hukuktitle" value="<?php echo $row['hukuk_title']; ?>" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Hukuk Desc</label>

								<div class="controls">

								  <input class="input-xlarge focused" value="<?php echo $row['hukuk_desc']; ?>" name="hukukdesc" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Hukuk Key</label>

								<div class="controls">

								  <input class="input-xlarge focused" name="hukukkey" value="<?php echo $row['hukuk_key']; ?>" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Tr Title</label>

								<div class="controls">

								  <input class="input-xlarge focused" name="trtitle" value="<?php echo $row['tr_title']; ?>" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Tr Desc</label>

								<div class="controls">

								  <input class="input-xlarge focused" name="trdesc" id="focusedInput" value="<?php echo $row['tr_desc']; ?>" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Tr Key</label>

								<div class="controls">

								  <input class="input-xlarge focused" name="trkey" value="<?php echo $row['tr_key']; ?>" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Dizi Title</label>

								<div class="controls">

								  <input class="input-xlarge focused" name="dizititle" value="<?php echo $row['dizi_title']; ?>" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Dizi Desc</label>

								<div class="controls">

								  <input class="input-xlarge focused" name="dizidesc" value="<?php echo $row['dizi_desc']; ?>" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Dizi Key</label>

								<div class="controls">

								  <input class="input-xlarge focused" name="dizikey" value="<?php echo $row['dizi_key']; ?>" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Sezon Title</label>

								<div class="controls">

								  <input class="input-xlarge focused" value="<?php echo $row['sezon_title']; ?>" name="sezontitle" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Sezon Desc</label>

								<div class="controls">

								  <input class="input-xlarge focused" name="sezondesc" value="<?php echo $row['sezon_desc']; ?>" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Sezon Key</label>

								<div class="controls">

								  <input class="input-xlarge focused" name="sezonkey" value="<?php echo $row['sezon_key']; ?>" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Dizi Film Title</label>

								<div class="controls">

								  <input class="input-xlarge focused" name="dizifilmtitle" value="<?php echo $row['dizle_title']; ?>" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Dizi Film Desc</label>

								<div class="controls">

								  <input class="input-xlarge focused" name="dizifilmdesc" value="<?php echo $row['dizle_desc']; ?>" id="focusedInput" type="text" />

								</div>

							 </div>

							 <div class="control-group">

								<label class="control-label" for="focusedInput">Dizi Film Key</label>

								<div class="controls">

								  <input class="input-xlarge focused" name="dizifilmkey" value="<?php echo $row['dizle_key']; ?>" id="focusedInput" type="text" />

								</div>

							 </div>

							  <div class="form-actions">

								<input type="submit" name="post" value="Seo Düzenle" class="btn btn-primary"/>

							  </div>

							</fieldset>

						  </form>

				

					</div>

				</div>	</div>

				</div>

								