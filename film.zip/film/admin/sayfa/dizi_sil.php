<?php 
$id = $_GET['id'];

$baglan = new mysqli("localhost", "root", "", "film");

if ($baglan->connect_error) {
    die("Bağlantı hatası: " . $baglan->connect_error);
}

$sil = $baglan->query("DELETE FROM diziler WHERE id='$id'");

if ($sil) {
    echo '<script language="javascript">
    $(function(){
        var saniye = 3;
        $.geriyeSay = function(){
            if (saniye > 1){
                saniye--;
            } else {
                window.close();
            }
        }
        setInterval("$.geriyeSay()", 1000);
    });
    </script>';
}

$baglan->close();
?><div class="row-fluid">
				<div class="box span12">
					<div class="box-header well">
						<h2><i class="icon-info-sign"></i>Dizi Silme</h2>
						<div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					<div class="box-content">
					<p><font color="red">Dizi Başarılı Bir şekilde silindi</font></p>
					
