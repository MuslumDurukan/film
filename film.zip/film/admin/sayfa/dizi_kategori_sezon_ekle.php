<?php dizi_kategori_sezon_ekle(); ?>
<div class="row-fluid sortable">
				<div class="box span12"><div class="box-header well" data-original-title>
						<h2><i class="icon-edit"></i> Dizi Kategori Sezon Ekle</h2>
						<div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
		<div class="box-content">
						<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
							<fieldset>
							  <div class="control-group">
								<label class="control-label" for="focusedInput">Sezon Adı:</label>
								<div class="controls">
								  <input class="input-xlarge focused" name="isim" id="focusedInput" type="text" />
								</div>
							  </div>


							  <div class="control-group">
								<label class="control-label" for="focusedInput">Sezon Seo:</label>
								<div class="controls">
								  <input class="input-xlarge focused" name="kategoriseo" id="focusedInput" type="text" />
								</div>
							  </div>
						
				
				 <div class="control-group">
								<label class="control-label" for="focusedInput">Sezon Dizi Kat.</label>
								<div class="controls">
								  <select name="kat" id="selectError1" multiple data-rel="chosen">
								  <?php 
$baglan = new mysqli("localhost", "root", "", "film");

if ($baglan->connect_error) {
    die("Bağlantı hatası: " . $baglan->connect_error);
}

$bul = $baglan->query("select * from dizikat");

while ($row = $bul->fetch_assoc()) {
    $id = $row['id'];
    $sezon_isim = $row['kat_isim'];
    echo '<option value="'.$id.'">'.$sezon_isim.'</option>';
}

$baglan->close();
?>
								  </select>
					</div></div>

							

							  <div class="control-group">
								<label class="control-label" for="focusedInput">Title:</label>
								<div class="controls">
								  <input class="input-xlarge focused" name="title" id="focusedInput" type="text" />
								</div>
							  </div>
						 <div class="control-group">
								<label class="control-label" for="focusedInput">Keyword:</label>
								<div class="controls">
								  <input class="input-xlarge focused" name="key" id="focusedInput" type="text" />
								</div>
							  </div>
							 <div class="control-group">
								<label class="control-label" for="focusedInput">Description:</label>
								<div class="controls">
								  <input class="input-xlarge focused" name="desc" id="focusedInput" type="text" />
								</div>
							  </div>
							 <div class="control-group">
								<label class="control-label">Resim Ekle</label>
								<div class="controls">
								  <input name="resim" type="file">
								</div>
							  </div>
							   <div class="control-group">
								<label class="control-label" for="focusedInput">İstersen sen yaz</label>
								<div class="controls">
								  <input class="input-xlarge focused" name="eski_resim_url" id="focusedInput" type="text" />
					</div></div>
							  <div class="form-actions">
								<input type="submit" name="post" value="Kategori Ekle" class="btn btn-primary"/>
							  </div>
							</fieldset>
						  </form>
				
					</div>
				</div>	</div>
				</div>
								