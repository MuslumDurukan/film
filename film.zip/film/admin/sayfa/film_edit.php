<?php
film_duzenle();

$id = $_GET['id'];
$baglan = new mysqli("localhost", "root", "", "film");

if ($baglan->connect_error) {
    die("Bağlantı hatası: " . $baglan->connect_error);
}

$film_query = $baglan->query("SELECT * FROM filmler WHERE id = '$id'");
$row = $film_query->fetch_assoc();

$seo = $row['sef'];
$isim = $row['isim'];
$yapim = $row['yapim'];
$yonetmen = $row['yonetmen'];
$imdb = $row['imdb'];
$ozet = $row['ozet'];
$title = $row['title'];
$description = $row['description'];
$keyw = $row['keyw'];
$oyuncu = $row['oyuncu'];
$embed = $row['embed'];
$manset = $row['manset'];
$dublaj = $row['dublaj'];
$kategori = $row['kategori'];

$baglan->close();
?>
<div class="row-fluid sortable">
				<div class="box span12"><div class="box-header well" data-original-title>
						<h2><i class="icon-edit"></i> <?php echo $row['isim'];?></h2>
						<div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
		<div class="box-content">
						<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
							<fieldset>
							  <div class="control-group">
								<label class="control-label" for="focusedInput">Film Adı</label>
								<div class="controls">
								  <input value="<?php echo $isim;?>" class="input-xlarge focused" name="isim" id="focusedInput" type="text" />
								</div>
							  </div>
	  <div class="control-group">
								<label class="control-label" for="focusedInput">SEO:</label>
								<div class="controls">
								  <input value="<?php echo $seo;?>" class="input-xlarge focused" name="sef" id="focusedInput" type="text" />
								</div>
							  </div>

							  <div class="control-group">
								<label class="control-label" for="focusedInput">Yapım:</label>
								<div class="controls">
								  <input value="<?php echo  $yapim;?>" class="input-xlarge focused" name="yapim" id="focusedInput" type="text" />
								</div>
							  </div>
							 <div class="control-group">
								<label class="control-label" for="focusedInput">Yönetmen:</label>
								<div class="controls">
								  <input value="<?php echo $yonetmen;?>" class="input-xlarge focused" name="yonetmen" id="focusedInput" type="text" />
								</div>
							  </div>
							 <div class="control-group">
								<label class="control-label" for="focusedInput">Oyuncu:</label>
								<div class="controls">
								  <input value="<?php echo $oyuncu;?>" class="input-xlarge focused" name="oyuncu" id="focusedInput" type="text" />
								</div>
							  </div>
							  <div class="control-group">
								<label class="control-label" for="focusedInput">İmdb</label>
								<div class="controls">
								  <input value="<?php echo $imdb;?>" class="input-xlarge focused" name="imdb" id="focusedInput" type="text" />
								</div>
							  </div>
							<div class="control-group">
								<label class="control-label" for="focusedInput">Embed:</label>
								<div class="controls">
								<textarea class="input-xlarge focused" name="embed" id="focusedInput"><?php echo $embed;?></textarea>
								</div>
							  </div>
						<div class="control-group">
								<label class="control-label" for="focusedInput">Özet:</label>
								<div class="controls">
								<textarea class="input-xlarge focused" name="ozet" id="focusedInput"><?php echo $ozet;?></textarea>
								  
								</div>
							  </div>
					  <div class="control-group">
								<label class="control-label" for="selectError">Manşet</label>
								<div class="controls">
								  <select name="manset"  >
								  <?php 
								  if($manset == 0){
								  echo '<option value="1">Evet</option>
									<option selected value="0">Hayır</option>';
								  }
								  else{
								  echo '<option selected value="1">Evet</option>
									<option  value="0">Hayır</option>';
								  }
								  ?>

								  </select>
								</div>
					</div>
				 <div class="control-group">
								<label class="control-label" for="selectError">Dil</label>
								<div class="controls">
								  <select name="dil"  >
								  <?php 
								  if ( $dublaj == 1){echo '<option selected value="1">Türçke Dublaj</option><option value="2">Alt Yazılı</option><option value="0">Türkçe</option>';}
								  elseif ( $dublaj == 0){echo '<option  value="1">Türçke Dublaj</option><option value="2">Alt Yazılı</option><option selected value="0">Türkçe</option>';}
								  elseif(  $dublaj == 2){echo '<option  value="1">Türçke Dublaj</option><option selected value="2">Alt Yazılı</option><option value="0">Türkçe</option>';}
								  
								  ?>

								  </select>
								</div>
					</div>
							  <div class="control-group">
								<label class="control-label" for="selectError1">Kategori Seç</label>
								<div class="controls">
								  <select name="kat[]" id="selectError1" multiple data-rel="chosen">
								  <?php 
$mysqli = new mysqli("localhost", "root", "", "film");

if ($mysqli->connect_error) {
    die("Bağlantı hatası: " . $mysqli->connect_error);
}

$query = $mysqli->query("SELECT * FROM kategori");
while ($row = $query->fetch_assoc()) {
    $kat_id = $row['id'];
    $selected = (strstr($kategori, $kat_id)) ? 'selected' : '';
    echo '<option ' . $selected . ' value="' . $row['id'] . '">' . $row['kat_isim'] . '</option>';
}

$mysqli->close();
?>
								  </select>
								</div>
							  </div>
							 <div class="control-group">
								<label class="control-label">Resim Ekle</label>
								<div class="controls">
								  <input name="resim" type="file">
								</div>
							  </div>
							  <div class="control-group">
								<label class="control-label" for="focusedInput">Title:</label>
								<div class="controls">
								  <input  value="<?php echo $title; ?>" class="input-xlarge focused" name="title" id="focusedInput" type="text" />
								</div>
							  </div>
						 <div class="control-group">
								<label class="control-label" for="focusedInput">Keyword:</label>
								<div class="controls">
								  <input value="<?php echo $keyw;?>" class="input-xlarge focused" name="key" id="focusedInput" type="text" />
								</div>
							  </div>
							  							  <div class="control-group">
								<label class="control-label" for="focusedInput">Description:</label>
								<div class="controls">
								  <input value="<?php echo $description; ?>" class="input-xlarge focused" name="desc" id="focusedInput" type="text" />
								</div>
							  </div>
							  <div class="form-actions">
							  <input type="hidden" name="id" value="<?php echo $id; ?>" />
								<input type="submit" name="post" value="Filmi Düzenle" class="btn btn-primary"/>
							  </div>
							</fieldset>
						  </form>
				
					</div>
				</div>	</div>
				</div>
						