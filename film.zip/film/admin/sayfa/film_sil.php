<?php
$mysqli = new mysqli("localhost", "root", "", "film");

if ($mysqli->connect_error) {
    die("Bağlantı hatası: " . $mysqli->connect_error);
}

$id = $_GET['id'];
$sil = $mysqli->query("DELETE FROM filmler WHERE id='$id' ");

if ($sil) {
    $mysqli->close();
    echo '<script language="javascript">
        $(function(){
            var saniye = 3;
            $.geriyeSay = function(){
                if (saniye > 1){
                    saniye--;
                } else {
                    window.close();
                }
            }
            setInterval("$.geriyeSay()", 1000);
        });
    </script>';
} else {
    echo "Silme işlemi başarısız: " . $mysqli->error;
    $mysqli->close();
}
?><div class="row-fluid">
				<div class="box span12">
					<div class="box-header well">
						<h2><i class="icon-info-sign"></i>Film Silme</h2>
						<div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					<div class="box-content">
					<p><font color="red">Film Başarılı Bir şekilde silindi</font></p>
					
