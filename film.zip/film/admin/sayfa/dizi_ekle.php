<?php diziekle(); ?><div class="row-fluid sortable">
				<div class="box span12"><div class="box-header well" data-original-title>
						<h2><i class="icon-edit"></i> Dizi Ekle</h2>
						<div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
		<div class="box-content">
						<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
							<fieldset>
							  <div class="control-group">
								<label class="control-label" for="focusedInput">Dizi İsmi:</label>
								<div class="controls">
								  <input class="input-xlarge focused" name="isim" id="focusedInput" type="text" />
								</div>
							  </div>
							<div class="control-group">
								<label class="control-label" for="focusedInput">Embed:</label>
								<div class="controls">
								<textarea class="input-xlarge focused" name="embed" id="focusedInput"></textarea>
								</div>
							  </div>
						<div class="control-group">
								<label class="control-label" for="focusedInput">Özet:</label>
								<div class="controls">
								<textarea class="input-xlarge focused" name="ozet" id="focusedInput"></textarea>
								  
								</div>
							  </div>
	
				 <div class="control-group">
								<label class="control-label" for="selectError">Dil</label>
								<div class="controls">
								  <select name="dil" id="selectError" >
									<option value="1">Türçke Dublaj</option>
									<option value="2">Alt Yazılı</option>
									<option value="0">Türkçe</option>
								  </select>
								</div>
					</div>
							  <div class="control-group">
								<label class="control-label" for="selectError1">Sezon Seç</label>
								<div class="controls">
								  <select name="kat" id="selectError1" multiple data-rel="chosen">
<?php 
$baglan = new mysqli("localhost", "root", "", "film");

if ($baglan->connect_error) {
    die("Bağlantı hatası: " . $baglan->connect_error);
}

$query = "SELECT * FROM dizisezon";
$result = $baglan->query($query);

while ($row = $result->fetch_assoc()) {
    echo '<option value="' . $row['id'] . '">' . $row['sezonisim'] . '</option>';
}

$baglan->close();
?>
								  </select>
								</div>
							  </div>
							 <div class="control-group">
								<label class="control-label">Resim Ekle</label>
								<div class="controls">
								  <input name="resim" type="file">
								</div>
							  </div>
							  <div class="control-group">
								<label class="control-label" for="focusedInput">Title:</label>
								<div class="controls">
								  <input class="input-xlarge focused" name="title" id="focusedInput" type="text" />
								</div>
							  </div>
						 <div class="control-group">
								<label class="control-label" for="focusedInput">Keyword:</label>
								<div class="controls">
								  <input class="input-xlarge focused" name="key" id="focusedInput" type="text" />
								</div>
							  </div>
							  							  <div class="control-group">
								<label class="control-label" for="focusedInput">Description:</label>
								<div class="controls">
								  <input class="input-xlarge focused" name="desc" id="focusedInput" type="text" />
								</div>
							  </div>
							  <div class="form-actions">
								<input type="submit" name="post" value="Filmi Ekle" class="btn btn-primary"/>
							  </div>
							</fieldset>
						  </form>
				
					</div>
				</div>	</div>
				</div>
								