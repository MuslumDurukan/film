<?php 
$baglan = new mysqli("localhost", "root", "", "film");

if ($baglan->connect_error) {
    die("Bağlantı hatası: " . $baglan->connect_error);
}

$id = $_GET['id'];
$query = "SELECT * FROM dizikat WHERE id = '$id'";
$result = $baglan->query($query);
$row = $result->fetch_array(MYSQLI_ASSOC);

dizi_kategori_duzenle();

$baglan->close();
?>
<div class="row-fluid sortable">
				<div class="box span12"><div class="box-header well" data-original-title>
						<h2><i class="icon-edit"></i><?php echo $row['kat_isim']; ?> Kategorisini Düzenle</h2>
						<div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
		<div class="box-content">
						<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
							<fieldset>
							  <div class="control-group">
								<label class="control-label" for="focusedInput">Kategori Adı:</label>
								<div class="controls">
								  <input class="input-xlarge focused" value="<?php echo $row['kat_isim']; ?>" name="kategori" id="focusedInput" type="text" />
								</div>
							  </div>


							  <div class="control-group">
								<label class="control-label" for="focusedInput">Kategori Seo:</label>
								<div class="controls">
								  <input class="input-xlarge focused" value="<?php echo $row['kat_seo']; ?>" name="kategoriseo" id="focusedInput" type="text" />
								</div>
							  </div>
						
				
					
							
							  <div class="control-group">
								<label class="control-label" for="focusedInput">Title:</label>
								<div class="controls">
								  <input class="input-xlarge focused" value="<?php echo $row['title']; ?>" name="title" id="focusedInput" type="text" />
								</div>
							  </div>
						 <div class="control-group">
								<label class="control-label" for="focusedInput">Keyword:</label>
								<div class="controls">
								  <input class="input-xlarge focused" value="<?php echo $row['keyw']; ?>"  name="key" id="focusedInput" type="text" />
								</div>
							  </div>
							  							  <div class="control-group">
								<label class="control-label" for="focusedInput">Description:</label>
								<div class="controls">
								  <input class="input-xlarge focused" value="<?php echo $row['description']; ?>" name="desc" id="focusedInput" type="text" />
								</div>
							  </div>
							  <div class="form-actions">
								<input type="submit" name="post" value="Kategori Düzenle" class="btn btn-primary"/>
							  </div>
							</fieldset>
						  </form>
				
					</div>
				</div>	</div>
				</div>
								