<div class="row-fluid sortable">		
				<div class="box span12">
					<div class="box-header well" data-original-title>
						<h2><i class="icon-user"></i> Dizile</h2>
						<div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>Dizi İsmi</th>
								  <th>Küçük Resim</th>
								  <th>Yapılacaklar</th>
							  </tr>
						  </thead>   
						  <tbody>
<?php 
$baglan = new mysqli("localhost", "root", "", "film");

if ($baglan->connect_error) {
    die("Bağlantı hatası: " . $baglan->connect_error);
}

$film_cek = $baglan->query("select * from diziler order by ID");

while ($row = $film_cek->fetch_assoc()) {
    $isim  = htmlspecialchars($row['isim']);
    $id    = $row['id'];
    $resim = $row['resim'];
    $sef   = $row['sef'];

    echo '<tr>
            <td>'.$isim.'</td>
            <td class="center">
                <a target="_blank" href="'.$resim.'">
                    <img src="'.$resim.'" width="50" height="50" alt="'.$isim.'"/>
                </a>
            </td>
            <td class="center">
                <a class="btn btn-success" target="_blank" href="'.URL.'/'.DIZIIZLEURL.'/'.$sef.'">
                    <i class="icon-zoom-in icon-white"></i>  
                    Diziye Bak                                       
                </a>
                <a class="btn btn-info" href="panel.php?do=dizi_edit&id='.$id.'">
                    <i class="icon-edit icon-white"></i>  
                    Düzenle                                            
                </a>
                <a class="btn btn-danger" href="panel.php?do=dizi_sil&id='.$id.'" target="_blank" >
                    <i class="icon-trash icon-white"></i> 
                    Sil
                </a>
            </td>
        </tr>';
}

$baglan->close();
?>
							
							
									  </tbody>
					  </table>            
					</div>
				</div><!--/span-->
			
			</div>