<?php
$mysqli = new mysqli("localhost", "root", "", "film");

if ($mysqli->connect_error) {
    die("Bağlantı hatası: " . $mysqli->connect_error);
}

$id = $_GET['id'];
$sil = $mysqli->query("DELETE FROM kategori WHERE id='$id' ");

if ($sil) {
    echo '<script language="javascript">
        $(function(){
            var saniye = 3;
            $.geriyeSay = function(){
                if (saniye > 1){
                    saniye--;
                } else {
                    window.close();
                }
            }
            setInterval("$.geriyeSay()", 1000);
        });
    </script>';
}

$mysqli->close();
?><div class="row-fluid">
				<div class="box span12">
					<div class="box-header well">
						<h2><i class="icon-info-sign"></i>Kategori Silme</h2>
						<div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					<div class="box-content">
					<p><font color="red">Kategoris Başarılı Bir şekilde silindi</font></p>
					
<meta http-equiv="refresh" content="1;URL=<?php echo URL.'/admin/panel.php?do=film_kategori_duzenle'; ?>">
