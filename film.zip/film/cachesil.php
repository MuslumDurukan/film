<?php
header('Content-Type: text/plain; charset=utf-8');

function klasor_temizle($klasor) {
    if (!is_dir($klasor)) {
        return; // Klasör mevcut değilse işlemi sonlandır
    }

    $ac = opendir($klasor);

    if (!$ac) {
        die("Klasör açılamadı: $klasor");
    }

    while (false !== ($dosya = readdir($ac))) {
        if ($dosya != '.' and $dosya != '..') {
            $dosya2 = $klasor . DIRECTORY_SEPARATOR . $dosya;

            if (is_dir($dosya2)) {
                // Sadece cache klasörü içindeki dosyaları sil
                if (basename($klasor) === 'cache') {
                    unlink($dosya2);
                } else {
                    klasor_temizle($dosya2);
                    rmdir($dosya2);
                }
            } else {
                unlink($dosya2);
            }
        }
    }

    closedir($ac);
}

echo 'Önbellek temizleme işlemi başlatıldı.' . "\n";

// __DIR__ kullanarak dosyanın bulunduğu dizini al
klasor_temizle(__DIR__ . DIRECTORY_SEPARATOR . 'cache');

echo 'Önbellek temizleme işlemi tamamlandı. Önbellek başarıyla boşaltıldı.';
?>