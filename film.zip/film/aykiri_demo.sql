-- phpMyAdmin SQL Dump
-- version 4.1.8
-- http://www.phpmyadmin.net
--
-- Anamakine: localhost
-- Üretim Zamanı: 05 Haz 2014, 16:24:32
-- Sunucu sürümü: 5.5.36-cll
-- PHP Sürümü: 5.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Veritabanı: `aykiri_demo`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `bozukdizi`
--

CREATE TABLE IF NOT EXISTS `bozukdizi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `film_isim` varchar(255) COLLATE utf8_bin NOT NULL,
  `film_seo` varchar(255) COLLATE utf8_bin NOT NULL,
  `film_id` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2 ;

--
-- Tablo döküm verisi `bozukdizi`
--

INSERT INTO `bozukdizi` (`id`, `film_isim`, `film_seo`, `film_id`) VALUES
(1, 'How I Met Your Mother 1. Sezon 1. Bölüm', 'how-i-met-your-mother-1-sezon-1-bolum-88.html', '1');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `bozukfilm`
--

CREATE TABLE IF NOT EXISTS `bozukfilm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `film_isim` varchar(255) COLLATE utf8_bin NOT NULL,
  `film_seo` varchar(255) COLLATE utf8_bin NOT NULL,
  `film_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=11 ;

--
-- Tablo döküm verisi `bozukfilm`
--

INSERT INTO `bozukfilm` (`id`, `film_isim`, `film_seo`, `film_id`) VALUES
(9, 'Asabi Adam – The Angriest Man in Brooklyn 2014 Türkçe Dublaj izle', 'asabi-adam-the-angriest-man-in-brooklyn-2014-turkce-dublaj-izle-88.html', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dizikat`
--

CREATE TABLE IF NOT EXISTS `dizikat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kat_seo` varchar(250) COLLATE utf8_bin NOT NULL,
  `kat_isim` varchar(250) COLLATE utf8_bin NOT NULL,
  `title` text COLLATE utf8_bin NOT NULL,
  `keyw` text COLLATE utf8_bin NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=8 ;

--
-- Tablo döküm verisi `dizikat`
--

INSERT INTO `dizikat` (`id`, `kat_seo`, `kat_isim`, `title`, `keyw`, `description`) VALUES
(7, 'how-i-met-your-mother-14', 'How I Met Your Mother', 'How I Met Your Mother dizisi izle', 'how i met your mother hd izle,donmadan izle,keyw yazıyoruz', 'How I Met Your Mother yabancı dizisini sitemizden ücretsiz olarak izleyebilirsiniz.');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `diziler`
--

CREATE TABLE IF NOT EXISTS `diziler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sef` varchar(250) CHARACTER SET utf8 NOT NULL,
  `isim` varchar(250) CHARACTER SET utf8 NOT NULL,
  `resim` varchar(250) CHARACTER SET utf8 NOT NULL,
  `ozet` longtext CHARACTER SET utf8 NOT NULL,
  `kategori` varchar(100) CHARACTER SET utf8 NOT NULL,
  `embed` longtext CHARACTER SET utf8 NOT NULL,
  `dublaj` int(11) NOT NULL,
  `begeni` int(11) NOT NULL,
  `title` text COLLATE utf8_bin NOT NULL,
  `keyw` text COLLATE utf8_bin NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=5 ;

--
-- Tablo döküm verisi `diziler`
--

INSERT INTO `diziler` (`id`, `sef`, `isim`, `resim`, `ozet`, `kategori`, `embed`, `dublaj`, `begeni`, `title`, `keyw`, `description`) VALUES
(1, 'how-i-met-your-mother-1-sezon-1-bolum-88.html', 'How I Met Your Mother 1. Sezon 1. Bölüm', 'http://c-film.net/afis/45400353-52488-how_i_met_your_mother_s6_afiş[1].jpg', '', '1', '<!--Part 1-->\r\n<iframe scrolling="no" frameborder="0" width="440" height="330" webkitallowfullscreen mozallowfullscreen allowfullscreen src="http://dunyavid.com/iframe/5056421/"></iframe>', 2, 2, '', '', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dizisezon`
--

CREATE TABLE IF NOT EXISTS `dizisezon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sezonisim` varchar(250) COLLATE utf8_bin NOT NULL,
  `dizikatid` int(11) NOT NULL,
  `resim_url` varchar(250) COLLATE utf8_bin NOT NULL,
  `sef` varchar(255) COLLATE utf8_bin NOT NULL,
  `title` text COLLATE utf8_bin NOT NULL,
  `keyw` text COLLATE utf8_bin NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=5 ;

--
-- Tablo döküm verisi `dizisezon`
--

INSERT INTO `dizisezon` (`id`, `sezonisim`, `dizikatid`, `resim_url`, `sef`, `title`, `keyw`, `description`) VALUES
(1, 'HIMYM 1. Sezon', 7, 'http://c-film.net/afis/76152796-89925-header_how-i-met-your-mother.jpg', 'himym-2-sezon-31', 'How I Met Your Mother 2. sezon dizisi izle', 'keyw', 'description');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `filmler`
--

CREATE TABLE IF NOT EXISTS `filmler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sef` varchar(250) CHARACTER SET utf8 NOT NULL,
  `isim` varchar(250) CHARACTER SET utf8 NOT NULL,
  `resim` varchar(250) CHARACTER SET utf8 NOT NULL,
  `yapim` varchar(150) CHARACTER SET utf8 NOT NULL,
  `yonetmen` varchar(250) CHARACTER SET utf8 NOT NULL,
  `oyuncu` varchar(250) CHARACTER SET utf8 NOT NULL,
  `ozet` longtext CHARACTER SET utf8 NOT NULL,
  `kategori` varchar(100) CHARACTER SET utf8 NOT NULL,
  `embed` longtext CHARACTER SET utf8 NOT NULL,
  `imdb` varchar(25) CHARACTER SET utf8 NOT NULL,
  `manset` int(11) NOT NULL DEFAULT '0',
  `dublaj` int(11) NOT NULL,
  `begeni` int(11) NOT NULL,
  `title` text COLLATE utf8_bin NOT NULL,
  `keyw` text COLLATE utf8_bin NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=14 ;

--
-- Tablo döküm verisi `filmler`
--

INSERT INTO `filmler` (`id`, `sef`, `isim`, `resim`, `yapim`, `yonetmen`, `oyuncu`, `ozet`, `kategori`, `embed`, `imdb`, `manset`, `dublaj`, `begeni`, `title`, `keyw`, `description`) VALUES
(1, 'asabi-adam-the-angriest-man-in-brooklyn-2014-turkce-dublaj-izle-88.html', 'Asabi Adam – The Angriest Man in Brooklyn 2014 Türkçe Dublaj izle', 'http://c-film.net/afis/19217837-69211-1-290x405[1].jpg', '2015', 'yönetmen', 'oyuncu', ' Filmde Robin Williams tarafından canlandırılan Henry Altmann isimli karakter, bir trafik kazasından sonra gittiği hastanede Mila Kunis''in canlandırdığı doktor Sharon Gill''in teşhisiyle, sadece 90 dakikalık ömrü kaldığını öğrenir. Ardından bugüne dek yaptığı hatalar için insanlardan af dilemek üzere New York''un altını üstüne getirecek bir maceraya atılır. iyi seyirler filmifullizle.com', ',1,2,3,16,5,6,7,8,9,10,11,12,13,14,15,', '<!--Part 1-->\r\n<iframe src="http://vk.com/video_ext.php?oid=254730478&id=169892854&hash=15427f402de9f35a&hd=2" width="607" height="360" frameborder="0"></iframe>\r\n<!--Part 2-->\r\n<iframe src="http://vk.com/video_ext.php?oid=254730478&id=169892856&hash=652d64d8fed51741&hd=2" width="607" height="360" frameborder="0"></iframe>\r\n<!--Part 3-->\r\n<iframe src="http://vk.com/video_ext.php?oid=254730478&id=169892860&hash=923cf87ca922b00e&hd=2" width="607" height="360" frameborder="0"></iframe>\r\n<!--Tek Parça VK-->\r\n<iframe src="http://vk.com/video_ext.php?oid=254730478&id=169892852&hash=3144f23115526dfe&hd=2" width="607" height="360" frameborder="0"></iframe>', '5.3', 1, 1, 1, '', '', ''),
(4, 'tanrilarin-cekici-full-hd-izle-68.html', 'Tanrıların Çekici Full Hd izle', 'http://c-film.net/afis/8757811-85141-137-290x405[1].jpg', '2013', 'yönetmen', 'oyuncu', 'Sıradan bir adamdan bir savaşçıya dönüşümün hikayesi. Steinar yıllar önce kardeşini kaybetmiştir. Kimin tarafıdnan kaçırıldığını bilmese de onu aramak için yollara düşer. Gittiği her yere aklını, cesaretini ve gücünü kullanarak zaferler taşır ve zamanla kendi ordusunu kurmaya başlar.', ',1,2,3,16,5,6,7,8,9,10,11,12,13,14,15,', '<!--Tek Part Hd İzle-->\r\n<iframe src="http://vk.com/video_ext.php?oid=204062180&id=169558422&hash=4945bdb951a895b6&hd=2" width="607" height="360" frameborder="0"></iframe>', '4.6', 1, 1, 1, '', '', ''),
(5, 'aclik-oyunlari-2-full-hd-izle.html', 'Açlık Oyunları 2', 'http://c-film.net/afis/11153116-110644-178-290x405[1].jpg', '2013', '', '', 'Katniss büyük bir fedakarlık yaparak kardeşinin yerine gönüllü olduğu oyunları kazandıktan sonra ülkesine dönmek için yola koyulurlar. Bu efsanevi galibetlerinin anısına 12 eyalette zafer kutlamalarına katılmaları gerekiyordur. Katniss bu ziyaretleri sırasında çıkacak ayaklanmaların kıvılcımlarını hissetmiştir. Durumun farkına varan Başkan Snow hemen bir müdahele ile halkın ilgisini başka bir yöne çekmeyi başarır. 75. yılını kutlayan Açlık Oyunlarında 25 yılda bir düzenlenen üçüncüsü düzenlenecek olan bir Çeyrek Asır Oyunları düzenleneceğini açıklar. Katniss daha galiyetinin tadını dahi çıkartamadan bu kez en yeteneklilerin bir arada olduğu bir ölüm kalım mücadelesinin içerisine dahil olacaktır.', ',1,2,3,16,5,6,7,8,9,10,11,12,13,14,15,', '<!--Tek Part Hd İzle-->\r\n<iframe src="http://vk.com/video_ext.php?oid=204062180&id=169558422&hash=4945bdb951a895b6&hd=2" width="607" height="360" frameborder="0"></iframe>', '7.2', 1, 1, 0, '', '', ''),
(6, 'kafesteki-kadin-3.html', 'Kafesteki Kadın', 'http://c-film.net/afis/19697969-119977-176-290x405[1].jpg', '2012', 'yönetmen', 'oyuncu', 'Polis müfettişi Carl Mørck, eski davaların tutulduğu Department Q’nun sorumlusu olarak atanır. Daha önce yine aynı bölüme atanan Esad ise yardımcısı olur. Kaybolan bir kadınla ilgili bir dava dikkatlerini çekecektir.', ',1,2,3,16,5,6,7,8,9,10,11,12,13,14,15,', '<!--Tek Part Hd İzle-->\r\n<iframe src="http://vk.com/video_ext.php?oid=204062180&id=169558422&hash=4945bdb951a895b6&hd=2" width="607" height="360" frameborder="0"></iframe>', '7.2', 1, 1, 0, '', '', ''),
(7, 'hirokin-full-hd-izle-55.html', 'Hirokin Full Hd izle', 'http://c-film.net/afis/7058683-142261-179-290x405[1].jpg', '2013', 'yönetmen', 'oyuncu', 'Hirokin, karanlık geçmişi ile nam salmış gönülsüz bir kahramandır. O ailesini öldürenlerden alacağı intikam ile bir halkın özgürlüğü için mücadele arasında seçim yapmak zorundadır.', ',1,2,3,16,5,6,7,8,9,10,11,12,13,14,15,', '<!--Tek Part Hd İzle-->\r\n<iframe src="http://vk.com/video_ext.php?oid=204062180&id=169558422&hash=4945bdb951a895b6&hd=2" width="607" height="360" frameborder="0"></iframe>', '4.6', 1, 1, 0, '', '', ''),
(8, 'kurt-45.html', 'Kurt', 'http://c-film.net/afis/16419238-23767-175-290x405[1].jpg', '2013', 'yönetmen', 'oyuncu', 'Savunma avukatı, müvekkilinin işlediği cinayetler için savunma yapmaya hazırlanır. Ancak cinayetlerin göründüğünden daha farklı olduğundan şüphelenmeye başlar.\r\n', ',1,2,3,16,5,6,7,8,9,10,11,12,13,14,15,', '<!--Tek Part Hd İzle-->\r\n<iframe src="http://vk.com/video_ext.php?oid=204062180&id=169558422&hash=4945bdb951a895b6&hd=2" width="607" height="360" frameborder="0"></iframe>', '4.6', 1, 1, 0, '', '', ''),
(9, 'siginak-2-92.html', 'Sığınak 2', 'http://c-film.net/afis/2952280-51109-14-290x405[1].png', '2013', 'yönetmen', 'oyuncu', 'Eski savaş suçlusu Klausener’in ölümsüz Nazi ordusuna karşı verilen mücadele…\r\n\r\nSene 1945… 2. Dünya Savaşı döneminde Alman bilim adamı Klausener korkunç bir teknoloji üzerinde çalışmaktadır: Ölümsüz bir nazi ordusu! Modern zamana geri döndüğümüzde ise NATO ordusu, Doğu Avrupa’dan korkunç bir haber almıştır. Nereden geldiği belli olmayan düşman güçleri, önüne çıkan herkesi acımasızca öldürmektedir. Eski savaş suçlusu Klausener’in uzun süredir izini sürmekte olan Helena (Catherine Steadman), bu olayın bir zombi ordusunun işi olduğunu bilen tek kişidir. Yıllardır Nazi sırlarını araştıran Wallace (Richard Coyle) ile birlik olurlar ve çok geçmeden özel bir harekat ekibi ile Doğu Avrupa’ya doğru yola çıkarlar.\r\nNot: Türkçe dublaj olarak yapılan ilk yayındır.', ',1,2,3,16,5,6,7,8,9,10,11,12,13,14,15,', '<!--Tek Part Hd İzle-->\r\n<iframe src="http://vk.com/video_ext.php?oid=204062180&id=169558422&hash=4945bdb951a895b6&hd=2" width="607" height="360" frameborder="0"></iframe>', '4.6', 1, 1, 0, '', '', ''),
(10, 'buyuk-yaris-26.html', 'Büyük Yarış', 'http://c-film.net/afis/73773494-90350-Büyük-Yarış-430x600.jpg', '2013', 'yönetmen', 'oyuncu', '3 ayrı rakib, ve 3 ayrı adam kuzey Amerika da rastlanan en nadir bulanan kuşları gözlemliyorlar. Kuş izleme yarışmasına katılmakta olan bu adamlar bir birlerini geçmek için kıyasıya rekabet içine giriyorlar. Doğa koşullarında yarışan dostlarımı her türlü engeli aşmak için kendilerini zorluyorlar. Aslında yaşadıkları her şey günlük hayatlarından birer kesittir. Nesli tükenmekte olan ve en nadir bulunan kuşları izlemek onlar için bir zevkti, fakat zaman içerisinde bir yarışma olduğu duyulur ve adamlarımız bu yarışmada gözlerini hırs bürüyecektir kazanmak için ne geliyorsa yapacaklardır. Üç komedi üstadını bir filmde birleştiren harika bir yapıttır. İyi seyirler dileriz filmizle.com.tr ailesi', ',1,2,3,16,5,6,7,8,9,10,11,12,13,14,15,', '<!--Tek Part Hd İzle-->\r\n<iframe src="http://vk.com/video_ext.php?oid=204062180&id=169558422&hash=4945bdb951a895b6&hd=2" width="607" height="360" frameborder="0"></iframe>', '5.6', 1, 1, 0, '', '', ''),
(11, 'bizim-kiz-6.html', 'Bizim Kız', 'http://c-film.net/afis/41215555-119851-bizimkiz[1].jpg', '1977', 'yönetmen', 'oyuncu', 'Hacer (Mürüvvet Sim), Ömer (Şemsi İnkaya), Tayfur (Öztürk Serengil), Haydar (Hüseyin Baradan) ve Cevriye (Toto Karaca) cami avlusunda bir bebek bulurlar; ismini de zeynep koymuşlardır.', ',1,2,3,16,5,6,7,8,9,10,11,12,13,14,15,', '<!--Tek Part Hd İzle-->\r\n<iframe src="http://vk.com/video_ext.php?oid=204062180&id=169558422&hash=4945bdb951a895b6&hd=2" width="607" height="360" frameborder="0"></iframe>', '6.5', 1, 0, 0, '', '', ''),
(12, 'gecmise-yolculuk-mayis-melegi-8.html', 'Geçmişe Yolculuk Mayıs Meleği', 'http://c-film.net/afis/84030848-10348-22-336x500[1].jpg', '2013', 'yönetmen', 'oyuncu', 'Annesiyle babasının boşanmasının ardından annesiyle küçük bir köyde yaşamaya başlayan astımlı bir çocuk olan Tom, mutsuz günlerini, çevrede bisikletiyle dolaşarak atlatmaya çalıştığı anda,kaybolmuşa benzeyen bir köpeğin peşinden gider ve kendini Yorkshire tepelerinde bir çiftliğin yıkılmış duvarları arasında keşfeder. Çevreyi dolaşırken bir duvardan düşen Tom, tam bu anda 1941′e, 2.Dünya Savaşı’nın İngiltere’yi kasıp kavurduğu döneme doğru zaman yolculuğuna çıkar.Geldiği çiftlikte, Sam Wheeler adında iyi niyetli bir adam, kızı Alison ve Sam’in sevgilisi Susan hayatını sürdürmektedir. Bu aile, 10 yaşlarında May adında küçük bir kızı yanlarına almıştır. May, savaş uçaklarının hava operasyonunda yıkılan şehirde, ailesiyle birlikte hayatını sürdürdüğü evin yıkıntıları arasında bir hafta yalnız kalmasının ardından bulunmuş ve bu çiftliğe, bir ailenin yanına gönderilmiştir. May’in hayatını sürdürdüğü korkunç travmanın izleri, Tom’un varlığı sayesinde biraz olsun hafifler. Eve girmeye korkan, kimseyle konuşmayan küçük kız onun sayesinde biraz açılır. Nihayet, Tom’un zamanı dolup, kendi zamanına geri gitmesi gerekir.', ',1,2,3,16,5,6,7,8,9,10,11,12,13,14,15,', '<!--Tek Part Hd İzle-->\r\n<iframe src="http://vk.com/video_ext.php?oid=204062180&id=169558422&hash=4945bdb951a895b6&hd=2" width="607" height="360" frameborder="0"></iframe>', '6.9', 1, 1, 0, '', '', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kat_seo` varchar(250) CHARACTER SET utf8 NOT NULL,
  `kat_isim` varchar(250) CHARACTER SET utf8 NOT NULL,
  `title` text COLLATE utf8_bin NOT NULL,
  `keyw` text COLLATE utf8_bin NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=26 ;

--
-- Tablo döküm verisi `kategori`
--

INSERT INTO `kategori` (`id`, `kat_seo`, `kat_isim`, `title`, `keyw`, `description`) VALUES
(1, 'aile1.html', 'Aile', 'Aile seo kendim yazdım1', 'asd1', 'asdsada1'),
(2, 'animasyon', 'Animasyon', '1', '11', '1'),
(3, 'dram', 'Dram', '', '', ''),
(16, 'fantastik', 'Fantastik', '', '', ''),
(5, 'bilimkurgu', 'Bilim Kurgu', '', '', ''),
(6, 'genclik', 'Gençlik', '', '', ''),
(7, 'gizem', 'Gizem', '', '', ''),
(8, 'komedi', 'Komedi', '', '', ''),
(9, 'korku-gerilim', 'Korku&Gerilim', '', '', ''),
(10, 'macera-aksiyon', 'Macera&Aksiyon', '', '', ''),
(11, 'polisiye-suc', 'Polisiye Suç', '', '', ''),
(12, 'psikolojik', 'Psikolojik', '', '', ''),
(13, 'romantik-duygusal', 'Romantik&Duygusal', '', '', ''),
(14, 'savas', 'Savaş', '', '', ''),
(15, 'spor', 'Spor', '', '', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `seo`
--

CREATE TABLE IF NOT EXISTS `seo` (
  `site_url` varchar(255) COLLATE utf8_bin NOT NULL,
  `ana_title` text COLLATE utf8_bin NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ana_desc` text COLLATE utf8_bin NOT NULL,
  `ana_key` text COLLATE utf8_bin NOT NULL,
  `title` text COLLATE utf8_bin NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  `keywords` text COLLATE utf8_bin NOT NULL,
  `kat_title` text COLLATE utf8_bin NOT NULL,
  `kat_key` text COLLATE utf8_bin NOT NULL,
  `kat_desc` text COLLATE utf8_bin NOT NULL,
  `begen_title` text COLLATE utf8_bin NOT NULL,
  `begen_key` text COLLATE utf8_bin NOT NULL,
  `begen_desc` text COLLATE utf8_bin NOT NULL,
  `hukuk_title` text COLLATE utf8_bin NOT NULL,
  `hukuk_key` text COLLATE utf8_bin NOT NULL,
  `hukuk_desc` text COLLATE utf8_bin NOT NULL,
  `tr_title` text COLLATE utf8_bin NOT NULL,
  `tr_desc` text COLLATE utf8_bin NOT NULL,
  `tr_key` text COLLATE utf8_bin NOT NULL,
  `dizi_title` text COLLATE utf8_bin NOT NULL,
  `dizi_key` text COLLATE utf8_bin NOT NULL,
  `dizi_desc` text COLLATE utf8_bin NOT NULL,
  `sezon_title` text COLLATE utf8_bin NOT NULL,
  `sezon_key` text COLLATE utf8_bin NOT NULL,
  `sezon_desc` text COLLATE utf8_bin NOT NULL,
  `dizle_title` text COLLATE utf8_bin NOT NULL,
  `dizle_key` text COLLATE utf8_bin NOT NULL,
  `dizle_desc` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2 ;

--
-- Tablo döküm verisi `seo`
--

INSERT INTO `seo` (`site_url`, `ana_title`, `id`, `ana_desc`, `ana_key`, `title`, `description`, `keywords`, `kat_title`, `kat_key`, `kat_desc`, `begen_title`, `begen_key`, `begen_desc`, `hukuk_title`, `hukuk_key`, `hukuk_desc`, `tr_title`, `tr_desc`, `tr_key`, `dizi_title`, `dizi_key`, `dizi_desc`, `sezon_title`, `sezon_key`, `sezon_desc`, `dizle_title`, `dizle_key`, `dizle_desc`) VALUES
('http://c-film.net', 'Full Hd Film izle 2013 Filmleri Vizyon Filmler', 1, 'Film izle Vizyondaki Filmler Türkçe Dublaj Türkçe Altyazı Komedi Film Aksiyon Film Yeni Çıkan Filmleri full hd film izleme kalitesi ile 1fullhdfilmizle.com da izle', 'film izle,hd film,vizyondaki filmler,2013 filmleri,hd film izle,türkçe dublaj film,aksiyon filmleri,türkçe altyazı filmler,1fullhdfilmizle,Vizyondaki Filmle izle,full film izle,filmi full izle,ko…', '{TITLE} Filmi İzle - Localhost Kalitesi İle Ücretsiz İzle', '{TITLE} hemen ücretsiz full hd film izleme kalitesi ile bu filmi türkçe dublaj olarak 720p kalitede donamadan bizim sitemizden izleyin. {TITLE} şimdi sizde bu filmi hd hızlı bir şekilde izlemek için siteye tıklayın.Film izle', '{TITLE} ücretsiz olarak,720p,full hd film izlemenin tek adresi, hemen izle,ücretsiz izle,full hd izle, {TITLE} hemen ücretsiz izle,fim izle,1080p izle', '{TITLE}', '{TITLE} keyw', '{TITLE} desc', 'BEĞEN TİTLE', 'BEĞEN KEY', 'BEĞEN DESC', 'HUKUK TİTLE', 'HUKUK KEy', 'HUKUK DESC', 'Türkçe Dublaj Filmler Full Hd izle', 'Türkçe dublaj filmleri full hd olarak sitemizden yüksel kalitede izleyebilirsiniz.', 'türkçe dublaj,türkçe dublaj film izle,tr film izle,türkçe film izle,film izle,hd film izle,full hd film izle', '{TITLE}', '{TITLE} key', '{TITLE} desc', '{TITLE} sezon title', '{TITLE} sezon key', '{TITLE} sezon desc', '{TITLE} dizi title', '{TITLE} dizi key', '{TITLE}dizi desc');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
