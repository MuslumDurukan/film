	<!-- Sağ blok Başlık -->

		<div class="sag-baslik">

			

			<!-- Butonlar -->

			<nav class="sag-butonlar">

				<ul>

					<li class="sag-buton-baslik">başlık</li>

				</ul>

			</nav>

			<!-- Butonlar Son -->

			

			<h2>404 SAYFA HATASI</h2>

		</div>

		<!-- Sağ blok Başlık Son -->

		

		<div class="clear"></div>

		

		<!-- Bloklar -->

		<nav class="blok-filmler">

			
<div class="wrapper row2">
  <div id="container" class="clear">
    <!-- ####################################################################################################### -->
    <!-- ####################################################################################################### -->
    <!-- ####################################################################################################### -->
    <!-- ####################################################################################################### -->
    <section id="fof" class="clear">
      <!-- ####################################################################################################### -->
      <div class="hgroup">
        <h1>404 Error</h1>
        <h2>Sorry, Nothing Found</h2>
      </div>
      <div class="positioned">
        <p>The Page You Requested Could Not Be Found On Our Server</p>
        <p>Vestibulumaccumsan egestibulum eu justo convallis augue estas aenean elit intesque sed. Facilispede estibulum nulla orna nisl velit elit ac aliquat non tincidunt. Namjusto cras urna urnaretra lor urna neque sed quis orci nulla.</p>
        <div id="respond" class="clear">
   
      </div>

    </section>
  
  </div>
</div>

		</nav>

		<!-- Bloklar Son -->

		

		<div class="clear"></div>

		

		<!-- Sağ blok Başlık -->

	

		<!-- Sağ blok Başlık Son -->

		

		

	</div>

	<!-- Sağ Blok Son -->