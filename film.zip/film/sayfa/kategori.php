			<?php

$kategori = g("kat");
$mysqli = new mysqli("localhost", "root", "", "film");

if ($mysqli->connect_error) {
    die("Bağlantı hatası: " . $mysqli->connect_error);
}

$kat_ara = $mysqli->query("SELECT * FROM kategori WHERE kat_seo = '$kategori'");
$kat_array = $kat_ara->fetch_assoc();
$kategori = $kat_array['kat_isim'];

$mysqli->close();

?>
	<!-- Sağ blok Başlık -->
		<div class="sag-baslik">
			
			<!-- Butonlar -->
			<nav class="sag-butonlar">
				<ul>

					<li class="sag-buton-baslik">başlık</li>
				</ul>
			</nav>
			<!-- Butonlar Son -->
			
			<h2><?php echo $kategori; ?></h2>
		</div>
		<!-- Sağ blok Başlık Son -->
		
		<div class="clear"></div>
		
		<!-- Bloklar -->
		<nav class="blok-filmler">
			<ul class="blok-film">
				<?php kategori_video(); ?>
			</ul>
		</nav>
		<!-- Bloklar Son -->
		
		<div class="clear"></div>
		
		<!-- Sağ blok Başlık -->
		<div class="sag-baslik">
			
			<!-- Butonlar -->
			<nav class="sayfalama-butonlar">
				<ul>
				<?php kategori_sayfa_ileri_geri(); ?>
				
				</ul>
			</nav>
			<nav class="sayfalama">
				<ul>
					<?php kategori_sayfa(); ?>
				</ul>
			</nav>
		</div>
			<!-- Butonlar Son -->
		<!-- Sağ blok Başlık Son -->
		
		
	</div>
	<!-- Sağ Blok Son -->