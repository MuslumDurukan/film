	<!-- Sağ blok Başlık -->
		<div class="sag-baslik">
			<!-- Butonlar -->
			<nav class="sag-butonlar">
				<ul>
					<li class="sag-buton-baslik">başlık</li>
				</ul>
			</nav>
			<!-- Butonlar Son -->
			<h2>En Çok Beğenilen  18 Film</h2>
		</div>
		<!-- Sağ blok Başlık Son -->
		<div class="clear"></div>
		<!-- Bloklar -->
		<nav class="blok-filmler">
			<ul class="blok-film">
				<?php en_cok_begeni_film(); ?>
			</ul>
		</nav>
		<!-- Bloklar Son -->
		<div class="clear"></div>
	</div>
	<!-- Sağ Blok Son -->