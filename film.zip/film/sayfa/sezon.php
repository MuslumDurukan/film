			<?php

$sef = g("sef");
$mysqli = new mysqli("localhost", "root", "", "film");

if ($mysqli->connect_error) {
    die("Bağlantı hatası: " . $mysqli->connect_error);
}

$query = $mysqli->prepare("SELECT * FROM dizisezon WHERE sef = ?");
$query->bind_param("s", $sef);
$query->execute();
$result = $query->get_result();
$array = $result->fetch_assoc();

$query->close();
$mysqli->close();

?>
	<!-- Sağ blok Başlık -->
		<div class="sag-baslik">
			
			<!-- Butonlar -->
			<nav class="sag-butonlar">
				<ul>

					<li class="sag-buton-baslik">başlık</li>
				</ul>
			</nav>
			<!-- Butonlar Son -->
			
			<h2><?php echo $array['sezonisim']; ?></h2>
		</div>
		<!-- Sağ blok Başlık Son -->
		
		<div class="clear"></div>
		
		<!-- Bloklar -->
		<nav class="blok-filmler">
			<ul class="blok-film">
				 <?php  sezon_video();  ?>
			</ul>
		</nav>
		<!-- Bloklar Son -->
		
		<div class="clear"></div>
		
		<!-- Sağ blok Başlık -->
		<div class="sag-baslik">
			
			<!-- Butonlar -->
			<nav class="sayfalama-butonlar">
				<ul>
				<?php  sezon_sayfa_ileri_geri();  ?>
				
				</ul>
			</nav>
			<nav class="sayfalama">
				<ul>
					<?php  sezon_sayfa();?>
				</ul>
			</nav>
		</div>
			<!-- Butonlar Son -->
		<!-- Sağ blok Başlık Son -->
		
		
	</div>
	<!-- Sağ Blok Son -->