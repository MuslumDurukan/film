	<!-- Sağ blok Başlık -->
		<div class="sag-baslik">
			
			<!-- Butonlar -->
			<nav class="sag-butonlar">
				<ul>
					<li class="sag-buton-baslik">başlık</li>
				</ul>
			</nav>
			<!-- Butonlar Son -->
			
			<h2>En Son Eklenen Filmler</h2>
		</div>
		<!-- Sağ blok Başlık Son -->
		
		<div class="clear"></div>
		
		<!-- Bloklar -->
		<nav class="blok-filmler">
			<ul class="blok-film">
				<?php enson_eklenen(); ?>
			</ul>
		</nav>
		<!-- Bloklar Son -->
		
		<div class="clear"></div>
		
		<!-- Sağ blok Başlık -->
		<div class="sag-baslik">
			
			<!-- Butonlar -->
			<nav class="sayfalama-butonlar">
				<ul>
					<?php anasayfa_ileri_geri(); ?>
				</ul>
			</nav>
			<!-- Butonlar Son -->
			
			<nav class="sayfalama">
				<ul>
					<?php ana_sayfa_sayfalma(); ?>
				</ul>
			</nav>
		</div>
		<!-- Sağ blok Başlık Son -->
		
		
	</div>
	<!-- Sağ Blok Son -->