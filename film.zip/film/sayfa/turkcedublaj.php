	<!-- Sağ blok Başlık -->
		<div class="sag-baslik">
			
			<!-- Butonlar -->
			<nav class="sag-butonlar">
				<ul>
					<li class="sag-buton-baslik">başlık</li>
				</ul>
			</nav>
			<!-- Butonlar Son -->
			
			<h2>Türkçe Dublaj Filmler</h2>
		</div>
		<!-- Sağ blok Başlık Son -->
		
		<div class="clear"></div>
		
		<!-- Bloklar -->
		<nav class="blok-filmler">
			<ul class="blok-film">
				<?php turkce_dublaj_film(); ?>
			</ul>
		</nav>
		<!-- Bloklar Son -->
		
		<div class="clear"></div>
		
		<!-- Sağ blok Başlık -->
		<div class="sag-baslik">
			
			<!-- Butonlar -->
			<nav class="sayfalama-butonlar">
				<ul>
					<?php turkce_dublaj_ileri_geri(); ?>
				</ul>
			</nav>
			<!-- Butonlar Son -->
			
			<nav class="sayfalama">
				<ul>
					<?php turce_dublaj_sayfalama(); ?>
				</ul>
			</nav>
		</div>
		<!-- Sağ blok Başlık Son -->
		
		
	</div>
	<!-- Sağ Blok Son -->