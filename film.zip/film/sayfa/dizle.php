<?php

$part = g("part");
$sef = g("sef");

$mysqli = new mysqli("localhost", "root", "", "film");

if ($mysqli->connect_error) {
    die("Bağlantı hatası: " . $mysqli->connect_error);
}

$query = $mysqli->query("SELECT * FROM diziler WHERE sef = '$sef'");
$say = $query->num_rows;

if ($say > 0) {
    $array = $query->fetch_assoc();
    $baslik = $array["isim"];
    $video_part = $array['embed'];
} else {
    echo '<meta http-equiv="refresh" content="0;URL=' . URL . '/404">';
}

$mysqli->close();

?>



	<!-- Sağ blok Başlık -->

		<div class="sag-baslik">

			

			<!-- Butonlar -->

			<nav class="icerik-butonlar">

				<ul>

	



					<li class="sag-buton-baslik">başlık</li>

				</ul>

			</nav>

			<!-- Butonlar Son -->

			

			<h2><?php echo $baslik; ?></h2>

		</div>

		<!-- Sağ blok Başlık Son -->

		

		<div class="clear"></div>

		

			<!-- Bloklar -->

		<div class="blok-filmler">
<br>
<div class="pTabGenel pTab2">
  			<ul class="pTabListe">
  			 <?php 
		     $ayir = explode('<!--',$video_part);
			 $say = count($ayir);
			 for($i=1;$i<$say;$i++){
			 $explode = explode('<!--',$video_part);
			 $explode = explode('-->',$explode[$i]);
			  echo '<li><a href="#">'.$explode[0].'</a></li>';
			 }
			 ?>
			 </ul>
			 <?php 
			    for($i=1;$i<$say;$i++){
				 $videopartayir = explode('-->',$video_part);
				 $videopartayir = explode('<!--',$videopartayir[$i]);
				 
				echo '<div class="pTabContent">'.$videopartayir[0].'</div>';
				
				}
			 
			 
			 ?>
  	   </div> 	


	<script type="text/javascript" src="<?php echo URL;?>/js/tab.js"></script>
	<script type="text/javascript" src="<?php echo URL;?>/js/tab2.js"></script>
	<script type="text/javascript">
	$(".pTab2").pTab({
		pTab: '.pTabListe',
		pTabElem: 'li',
		pClass: 'pAktif',
		pContent: '.pTabContent',
		pDuration: 1000,
		pEffect: 'fadeIn'
	});
	</script>


		</div>

		<div class="filme-ait-butonlar">

			<nav class="filme-ait-buton">

				<!--Kajax -->

<script type="text/javascript">

$(function(){

var sef = $('#sef').val();

$(".filmbegen").click(function(){

  $.post("/ajax/begendizi.php",

  {

    sef:sef,

  },

  function(data){

    alert(data );

  });



	});

	$(".bozuk").click(function(){

  $.post("/ajax/bozukdizi.php",

  {

    sef:sef,

  },

  function(data){

    alert(data );

  });



	});



});

</script>



<!--Kajax -->

				<ul>

				    <input type="hidden" value="<?php echo $sef; ?>" id="sef" />

					<li><a class="filmbegen" >Filmi Beğen - <?php echo $array['begeni'];?></a></li>

					<li><a class="bozuk">Bozuk Dizi</a></li>

				</ul>

				

			</nav>

		</div>

		<!-- Bloklar Son -->

	
		<div class="clear"></div>

		

		<!-- film Hakkında bilgiler -->

		<div class="film-hakkinda">

			<div class="film-hakkinda-sol">

				<img class="film-hakkinda-sol" src="<?php echo $array['resim']; ?>" alt="<?php echo $baslik ?>" />

			</div>

			<div class="film-hakkinda-sag">

	

				<p><span>Özet : </span><?php echo $array['ozet']; ?></p>

			</div>

		</div>

		<!-- film Hakkında bilgiler Son -->
		<!-- Sağ blok Başlık -->
		<div class="sag-baslik">
			
			<!-- film Hakkında -->
			<nav class="icerik-butonlar">
				<ul>
					<li class="sag-buton-tekpart">Yorumları Oku</li>
				</ul>
			</nav>
			<!-- film Hakkında Son -->
			
			<h2>FİLME YORUM YAP</h2>
		</div>
		<!-- Sağ blok Başlık Son -->
		
		<!-- film Hakkında bilgiler -->
		<div class="film-yorum">
       <div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/tr_TR/sdk.js#xfbml=1&appId=1396598277226672&version=v2.0";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div class="fb-comments" data-href="<?php echo URL.$_SERVER['REQUEST_URI']; ?>" data-numposts="5" data-colorscheme="light"></div>
			
		</div>
		<!-- film Hakkında bilgiler Son -->

		

	


		

	</div>

	<!-- Sağ Blok Son -->