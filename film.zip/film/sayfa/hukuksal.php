	<!-- Sağ blok Başlık -->
		<div class="sag-baslik">
			<!-- Butonlar -->
			<nav class="sag-butonlar">
				<ul>
					<li class="sag-buton-baslik">başlık</li>
				</ul>
			</nav>
			<!-- Butonlar Son -->
			<h2>Hukuksal</h2>
		</div>
		<!-- Sağ blok Başlık Son -->
		<div class="clear"></div>
		<!-- Bloklar -->
		<nav class="blok-filmler">
			<ul class="blok-film">
				<font class="yazi" >Sitemizde Bulunan Filmler ; Google.com, Vk.com, Youtube.com , Facebook.com , Mynet.Com, Mail.ru gibi sitelerden alınmış olup,içeriklerden sitemiz veya yöneticilerimiz sorumlu değildir.Eğer hak sahibi kişiyseniz mail adresimize e-posta gönderiniz.Mail Adresi: hukuk@1fullhdfilmizle.com .Gönderilen mail'ler pazar günü kontrol edilir ve bir hafta içinde gereği yapılır.</font>
			</ul>
		</nav>
		<!-- Bloklar Son -->
		<div class="clear"></div>
	</div>
	<!-- Sağ Blok Son -->
