	<!-- Sağ blok Başlık -->
		<div class="sag-baslik">
			
			<!-- Butonlar -->
			<nav class="sag-butonlar">
				<ul>
					<li class="sag-buton-baslik">başlık</li>
				</ul>
			</nav>
			<!-- Butonlar Son -->
			
			<h2><?php echo g("kelime"); ?></h2>
		</div>
		<!-- Sağ blok Başlık Son -->
		
		<div class="clear"></div>
		
		<!-- Bloklar -->
		<nav class="blok-filmler">
			<ul class="blok-film">
				<?php arama_video(); ?>
			</ul>
		</nav>
		<!-- Bloklar Son -->
		
		<div class="clear"></div>
		
	
		
		
	</div>
	<!-- Sağ Blok Son -->