<?php 
require_once("../inc/baglan2.php"); 
require_once("../inc/fonksiyon.php");

if ($_POST) {
    session_start();

    $sef = p('sef');

    $query = mysqli_query($baglan, "SELECT * FROM filmler WHERE sef ='$sef'");
    $array = mysqli_fetch_array($query);

    if ($_SESSION['oy'] == $sef) {
        echo "Daha önce zaten oy kullandınız";
    } else {
        $deger = $array['begeni'] + 1;

        $yeni_kayit = mysqli_query($baglan, "UPDATE filmler SET begeni = '$deger' WHERE sef = '$sef'");

        if ($yeni_kayit) {
            echo 'Oyunuz başarılı bir şekilde kayıt edilmiştir.';
        } else {
            echo 'Bir hata oluştu';
        }

        $_SESSION['oy'] = $sef;
    }
} else {
    echo '<meta http-equiv="refresh" content="0;URL=' . URL . '/404">';
}
?>