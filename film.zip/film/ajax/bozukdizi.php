<?php
require_once("../inc/baglan2.php");

$sef = $_POST['sef'];

$bul = mysqli_query($baglan, "SELECT * FROM diziler WHERE sef = '$sef'");
$row = mysqli_fetch_array($bul);

$isim = $row['isim'];
$id = $row['id'];

$varsa = mysqli_query($baglan, "SELECT * FROM bozukdizi WHERE film_id = '$id'");
$say = mysqli_num_rows($varsa);

if ($say > 0) {
    echo "Teşekkür ederiz, en kısa sürede kontrol edeceğiz.";
} else {
    $ekle = mysqli_query($baglan, "INSERT INTO bozukdizi (film_isim, film_seo, film_id) VALUES ('$isim','$sef','$id') ");
    if ($ekle) {
        echo "Teşekkür ederiz, en kısa sürede kontrol edeceğiz.";
    }
}
?>