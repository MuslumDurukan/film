<?php
session_start();

## LİSANS##
$key = "123123124124";

## Bağlantı değişkenleri ##
$host = "localhost";
$user = "root";
$pass = "";
$db   = "filmseverturk21";

## Mysqli bağlantısı ##
$baglan = mysqli_connect($host, $user, $pass, $db);

## Veritabanı Seçimi ##
if (!$baglan) {
    die("Veritabanı bağlantısı başarısız: " . mysqli_connect_error());
}

## Karakter Sorunu ##
mysqli_set_charset($baglan, 'utf8');
?>